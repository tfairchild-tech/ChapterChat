<?php

    ini_set('display_errors', 1);
    ini_set('display_startup_errors', 1);
    error_reporting(E_ALL);

	// Start the session
    if (session_status() == PHP_SESSION_NONE) {
        session_start();
    }
    if (isset($_POST["submitlogout"])) {

		//$login = $_POST["login"];
        //$loginType= $_POST["logintype"];
        //$scid = $_POST["scid"];

		if (isset($_SESSION["login"])) {
            unset($_SESSION['login']);
        }

        if (isset($_SESSION["logintype"])) {
            unset($_SESSION['logintype']);
        }

        //cleanup
        if (isset($_SESSION["loginType"])) {
            unset($_SESSION['loginType']);
        }

        if (isset($_SESSION["SCId"])) {
            unset($_SESSION['SCId']);
        }

        //header( 'Location: ./index.php' ) ;
		//die();
        echo "<script> window.location.replace('index.php') </script>";
	}
	
?>
<div class="modal fade" id="signoutModal" role="dialog">
    <div class="modal-dialog">

        <!-- Modal content-->
        <div class="modal-content">
            <div class="modal-header">
                <button type="button" class="close" data-dismiss="modal">&times;</button>
                <h4 class="modal-title">Sign Out</h4><br>
            </div>
            <div class="modal-body">

                    <div class="container">

                        <form class="form-signout" method="post" action="<?php echo $_SERVER['PHP_SELF']; ?>">
                            <div class="form-group">
                                <div class="row">
                                    <div class="col-md-4">
                                        <input type="hidden" id="login" name="login" class="form-control col-sm-4" value="<?php echo $_SERVER['login']; ?>">
                                        <input type="hidden" id="scid" name="scid" class="form-control col-sm-4" value="<?php echo $_SERVER['SCId']; ?>">
                                        <input type="hidden" id="loginType" name="loginType" class="form-control col-sm-4" value="<?php echo $_SERVER['loginType']; ?>">
                                    </div>
                                    <div class="col-md-8"></div>
                                </div>

                                <br>
                                    <div>
                                        <button class="btn btn-sm btn-primary" id="submitlogout" name="submitlogout" type="submit">Sign Out</button>
                                    </div>
                            </div>
                        </form>



                    </div> <!-- /container -->
            </div>
        </div>
    </div>
</div>
