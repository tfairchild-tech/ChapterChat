<?PHP 
include 'requirestudent.php';
include 'header.php'; 
	$bookTitle="";	
    if (isset($_POST["search"])) {
		$bookTitle = $_POST["bookTitle"];
		
		include('db_connect.php');

		$call = mysqli_prepare($conn, 'CALL ReadEdu.lookupBooks(?)');
		mysqli_stmt_bind_param($call, 's', $bookTitle);
		mysqli_stmt_execute($call);

		$result = $call ->get_result();
		$books="<table class='table table-striped table-bordered'>";
		$books= $books . '<tr><th>Book Cover</th>';
		$books= $books . '<th>Book Title</th>';
		$books= $books . '<th>Author Name</th>';
		$books= $books . '<th>Book Level</th>';
		$books= $books . '<th>Book Points</th>';
		$books= $books . '<th>ISBN</th>';
		$books= $books . '<th></th></tr>';
		
		while ($row = $result->fetch_assoc()) {
			$books= $books . '<tr>';
			$books= $books . '<td><img src="bookimages/Charlie_Bone_and_the_Hidden_King.jpg" /></td>';
			$books= $books . '<td>'.$row['bookTitle'].'</td>';
			$books= $books . '<td>'.$row['authorname'].'</td>';
			$books= $books . '<td>'.$row['BookLevel'].'</td>';
			$books= $books . '<td>'.$row['possiblePoints'].'</td>';
			$books= $books . '<td>'.$row['ISBN'].'</td>';
			$books= $books . '<td><a href="takeQuiz.php?bookId='.$row["bookId"].'">Take Quiz</a></td>';
			$books= $books . '</tr>';
		}
		$books= $books . '</table>';
		/* free result set */
		mysqli_free_result($result);		
		$call->close();	
		include 'db_close.php';
	}	
?>
<br/><br/>
<div class="jumbotron container">	
<h2 class="form-group-heading">Find a Book</h2>
<form class="form-signin" method="post" action="<?php echo $_SERVER['PHP_SELF']; ?>">
	<div class="form-group col-lg-6">
		<label for="bookTitle">Book Title</label>
		<div class="input-group">			
			<input type="text" id="bookTitle" name="bookTitle" class="form-control col-sm-4" placeholder="Book title" value="<?php echo $bookTitle ?>" required autofocus>
			<span class="input-group-btn">
				<button type="submit" name="search" class="btn btn-primary">Search</button>
			</span>
		</div>
	</div>
</form>
<?php
	if (isset($_POST["search"])) {
		echo ("<br/><br/><div>");
		echo ($books);
		echo ("</div>");
	}
?>
</div>