<?php include 'header.php';?>

<div class="container">
        <div class="row">
            <div >
                <div class="panel" style="width:25%;">
                    <div class="panel-heading chapterchat-font-hdr" style="background-image:none;background-color: #2E7B32; color:#7AB142;">Hello!</div>
                    <a href="#"><div class="panel-footer"><div class="text-center chapterchat-font">This page is about us :)</div></div></a>
                </div>

            </div>
        </div>
    </div>
