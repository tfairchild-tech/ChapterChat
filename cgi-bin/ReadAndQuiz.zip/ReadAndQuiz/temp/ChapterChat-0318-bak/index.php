<?php include 'header.php';?>

     <section id="ChapterChatMain" name="ChapterChatMain">
        <div class="container">
            <div class="row">
                <div >
                    <?php
                    if (isset($_SESSION["logintype"])) {
                        if ($_SESSION["loginType"] == 0) {
                            echo "<script> window.location.replace('studentHome.php') </script>";
                        } else {
                            echo "<script> window.location.replace('teacherHome.php') </script>";
                        }
                    } else {
                        echo "Main Page...";
                    }
                    ?>
                    <!--
					<div class="panel" style="width:25%;">
						<div class="panel-heading chapterchat-font-hdr" style="background-image:none;background-color: #2E7B32; color:#7AB142;">Student Summary</div>
						<div class="list-group" id='StudentSummary'></div>
						<a href="#"><div class="panel-footer"><div class="text-center chapterchat-font chapter-chat-nav-link" href="student_summary.php" data-target="#student" id="studentsummaryLink">View all</div></div></a>
					</div>
					<div class="panel panel-info" style="width:25%;">
						<div class="panel-heading chapterchat-font-hdr" style="background-image:none; background-color: #FFCD07; color:#FF8E00;">Quiz History</div>
						<div class="list-group"></div>
						<a href="#"><div class="panel-footer"><div class="text-center chapterchat-font chapter-chat-nav-link" href="quiz_summary.php" data-target="#quiz" id="quizsummaryLink">Take Quiz</div></div></a>
					</div>
					<div class="panel panel-success" style="width:25%;">
						<div class="panel-heading chapterchat-font-hdr" style="background-image:none; background-color: #1565C0; color:#62B3F5;">Book Shelf</div>
						<div class="list-group"></div>
						<a href="#bookshelf"><div class="panel-footer page-scroll"><div class="text-center chapterchat-font chapter-chat-nav-link"  href="bookshelf_summary.php" data-target="#bookshelf" id="bookshelfsummaryLink">View All</div></div></a>
						
					</div>
					-->
                </div>
            </div>
        </div>
    </section>
