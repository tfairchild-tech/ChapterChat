<?PHP 
	include 'requirestudent.php';
	include 'header.php'; 
	
	include('db_connect.php');
	ini_set('display_errors', 1);
	ini_set('display_startup_errors', 1);
	error_reporting(E_ALL);

	$studentQuizId = $_GET["studentQuizId"];

	$call = mysqli_prepare($conn, 'CALL ReadEdu.GetStudentQuizResult(?)');
	mysqli_stmt_bind_param($call, 'i', $studentQuizId);
	mysqli_stmt_execute($call);
	$result = $call ->get_result();		
	// display the result
	$summary='';
	while ($row = $result->fetch_assoc()) {
		$numOfQuestions= $row['numOfQuestions'];
		$summary= $summary . '<div class="row">';
		$summary= $summary . '<div class="col-md-3" ><img src="bookimages/big'.$row['picPath'].'" /></div>';
		$summary= $summary . '<div class="col-md-8" >';//2
		$summary= $summary . '<div class="row">';//1
		$summary= $summary . '<div class="col-md-8"><h3 class="underline">'.$row['BookTitle'].'</h3> By '.$row['authorname'].'</div>';
		$summary= $summary . '</div>';//1
		$summary= $summary . '<div class="row">';//4
		$summary= $summary . '<div class="col-md-3" ><b>Total Points:</b> '.$row['possiblePoints'].'</div>';
	
		if ($row['Passed']==1){
			$summary= $summary.'<div><img src="icons/welldone.png" />Congratulations, You have passed the Quiz, please review your answers below!</div>';			
		}else{
			$summary= $summary."<div class='warning'><img src='icons/f3.png' />You didn't pass the quiz, please review your answers below!</div>";	
		}
		$summary= $summary."<h2>You got ".$row['numCorrectQuestions']."/".$row['numOfQuestions']." correct question(s)!</h2>";
	}
	// now we're at the end of our first result set.
	mysqli_free_result($result);
	mysqli_stmt_close($call);
	//move to next result set
	//mysqli_next_result($call);	
	$call1 = mysqli_prepare($conn, 'CALL ReadEdu.GetStudentQuizResultAnswers(?)');
	mysqli_stmt_bind_param($call1, 'i', $studentQuizId);
	mysqli_stmt_execute($call1);

	$result2 = $call1 ->get_result();		
	
	$summary2= '';
	$qIdOld=0;
	$bol=1;		
	$qIndex=1;
	$qpass=0;	
	while ($row = $result2->fetch_assoc()) {
			$qId=$row["QId"];
			if  ($qId <> $qIdOld){
				if ($bol==0){
					$summary2= $summary2."</div></div><br>";
				}			
				$summary2= $summary2."<div id='".$qIndex."div'><div id='".$qIndex."colordiv'> ";
				
				$summary2= $summary2."<label class='radio control-label'>".$qIndex."/".$numOfQuestions.". ".$row["QText"]."</label>";
				$summary2= $summary2."<input type='hidden' id='passed".$qIndex."' value='".$qpass."'/>";
				$qIndex=$qIndex+1;				
				$qpass=0;
			}
			
			if ($row["Correct"] == 1)
				$summary2= $summary2."<div class='radio go'><label><input type='radio' id='".$qId."'  name='".$qId."'  value='".$row["AnswerId"]."'";
			else
				$summary2= $summary2."<div class='radio'><label><input type='radio' id='".$qId."'  name='".$qId."'  value='".$row["AnswerId"]."'";
				
			if  ($row["AnswerId"]== $row["studentAnswerId"])
				$summary2= $summary2." checked" ;
			$summary2= $summary2." disabled>".$row["AnswerText"]."</label></div>";	
			
			if ($row["AnswerId"] == $row["studentAnswerId"] && $row["Correct"] == 1){
				$qpass=1;
				 
			}
				
			$bol=0;
					
			$qIdOld= $qId;
			
	}
	$summary2= $summary2."<input type='hidden' id='passed".$qIndex."' value='".$qpass."'/></div></div><br>";		
	
	///mysqli_free_result($result2);
	// close statement
	//mysqli_stmt_close($call);	
?>
	<br/><br/>
	<div class="jumbotron container container-fluid">
	<?php echo $summary; ?>
	<br/>
	<br/><input type="hidden" name="numOfQuestions" id="numOfQuestions" value="<?php echo ($qIndex) ?>" />
	<?php echo $summary2; ?>
	</div>
	
	<script type="text/javascript">
	$(document).ready(function() {		
		numOfQuestions= $("#numOfQuestions").val();
		
		for (i=1 ; i< numOfQuestions; i++){
			i1=i+1;
			if ($('#passed'+i1).val() ==1){				
				$('#'+i+"colordiv").addClass('chapterchat-question-passed');
			}else
			{			
				$('#'+i+"colordiv").addClass('chapterchat-question-failed');
			}
		
		}
	});
	</script>