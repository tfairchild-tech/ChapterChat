<footer class="footer">
    <div class="container text-center">
        <p class="text-muted chapterchat-font-footer"><img src="assets/favicon-16x16.png">Chapter Chat<br>Copyright &copy;2017<br>Lina Haddad &amp; Traci Fairchild</p>
    </div>
</footer>