<?php
// Create connection
$conn = new mysqli("barbados.lno.att.com", "eduuser", "Edu4Read$");

if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}
?> 