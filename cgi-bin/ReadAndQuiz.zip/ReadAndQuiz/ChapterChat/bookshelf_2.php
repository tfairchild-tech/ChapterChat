<?php
include 'requirestudent.php';
include 'header.php';


?>
<link rel="stylesheet" href="css/bookshelf.css" />


<div class="container">

    <div class="jumbotron chapter_chat_bookshelf_jumbotron">

    <div class="row center-block">

            <div class="col-xs-4 col-md-2 book-img">
                <a href="" class="book-link"><img src="bookimages/Charlie_Bone_and_the_Hidden_King.jpg" class="img-responsive book"></a>
            </div>
            <div class="col-xs-4 col-md-2 book-img">
                <a href="" class="book-link"><img src="bookimages/The_Washington_Monument.jpg" class="img-responsive book"></a>
            </div>
            <div class="col-xs-4 col-md-2 book-img">
                <a href="" class="book-link"><img src="bookimages/Charlie_Bone_and_the_Hidden_King.jpg" class="img-responsive book"></a>
            </div>
            <div class="col-xs-12 shelf hidden-md hidden-lg"></div>

            <div class="col-xs-4 col-md-2 book-img">
                <a href="" class="book-link"><img src="bookimages/The_Washington_Monument.jpg" class="img-responsive book"></a>
            </div>
            <div class="col-xs-4 col-md-2 book-img">
                <a href="" class="book-link"><img src="bookimages/Charlie_Bone_and_the_Hidden_King.jpg" class="img-responsive book"></a>
            </div>
            <div class="col-xs-4 col-md-2 book-img">
                <a href="" class="book-link"><img src="bookimages/The_Washington_Monument.jpg" class="img-responsive book"></a>
            </div>
            <div class="col-xs-12 shelf"></div>


            <div class="col-xs-4 col-md-2 book-img">
                <a href="" class="book-link"><img src="bookimages/The_Washington_Monument.jpg" class="img-responsive book"></a>
            </div>
            <div class="col-xs-4 col-md-2 book-img">
                <a href="" class="book-link"><img src="bookimages/Charlie_Bone_and_the_Hidden_King.jpg" class="img-responsive book"></a>
            </div>
            <div class="col-xs-4 col-md-2 book-img">
                <a href="" class="book-link"><img src="bookimages/The_Washington_Monument.jpg" class="img-responsive book"></a>
            </div>
            <div class="col-xs-12 shelf hidden-md hidden-lg"></div>

            <div class="col-xs-4 col-md-2 book-img">
                <a href="" class="book-link"><img src="bookimages/Charlie_Bone_and_the_Hidden_King.jpg" class="img-responsive book"></a>
            </div>
            <div class="col-xs-4 col-md-2 book-img">
                <a href="" class="book-link"><img src="bookimages/The_Washington_Monument.jpg" class="img-responsive book"></a>
            </div>
            <div class="col-xs-4 col-md-2 book-img">
                <a href="" class="book-link"><img src="bookimages/Charlie_Bone_and_the_Hidden_King.jpg" class="img-responsive book"></a>
            </div>
            <div class="col-xs-12 shelf"></div>


        <div class="col-xs-4 col-md-2 book-img">
            <a href="" class="book-link"><img src="bookimages/The_Washington_Monument.jpg" class="img-responsive book"></a>
        </div>
        <div class="col-xs-4 col-md-2 book-img">
            <a href="" class="book-link"><img src="bookimages/Charlie_Bone_and_the_Hidden_King.jpg" class="img-responsive book"></a>
        </div>
        <div class="col-xs-4 col-md-2 book-img">
            <a href="" class="book-link"><img src="bookimages/The_Washington_Monument.jpg" class="img-responsive book"></a>
        </div>
        <div class="col-xs-12 shelf hidden-md hidden-lg"></div>

        <div class="col-xs-4 col-md-2 book-img">
            <a href="" class="book-link"><img src="bookimages/Charlie_Bone_and_the_Hidden_King.jpg" class="img-responsive book"></a>
        </div>
        <div class="col-xs-4 col-md-2 book-img">
            <a href="" class="book-link"><img src="bookimages/The_Washington_Monument.jpg" class="img-responsive book"></a>
        </div>
        <div class="col-xs-4 col-md-2 book-img">
            <a href="" class="book-link"><img src="bookimages/Charlie_Bone_and_the_Hidden_King.jpg" class="img-responsive book"></a>
        </div>
        <div class="col-xs-12 shelf"></div>


        <div class="col-xs-4 col-md-2 book-img">
            <a href="" class="book-link"><img src="bookimages/The_Washington_Monument.jpg" class="img-responsive book"></a>
        </div>
        <div class="col-xs-4 col-md-2 book-img">
            <a href="" class="book-link"><img src="bookimages/Charlie_Bone_and_the_Hidden_King.jpg" class="img-responsive book"></a>
        </div>
        <div class="col-xs-4 col-md-2 book-img">
            <a href="" class="book-link"><img src="bookimages/The_Washington_Monument.jpg" class="img-responsive book"></a>
        </div>
        <div class="col-xs-12 shelf hidden-md hidden-lg"></div>

        <div class="col-xs-4 col-md-2 book-img">
            <a href="" class="book-link"><img src="bookimages/Charlie_Bone_and_the_Hidden_King.jpg" class="img-responsive book"></a>
        </div>
        <div class="col-xs-4 col-md-2 book-img">
            <a href="" class="book-link"><img src="bookimages/The_Washington_Monument.jpg" class="img-responsive book"></a>
        </div>
        <div class="col-xs-4 col-md-2 book-img">
            <a href="" class="book-link"><img src="bookimages/Charlie_Bone_and_the_Hidden_King.jpg" class="img-responsive book"></a>
        </div>
        <div class="col-xs-12 shelf"></div>



        <div class="col-xs-4 col-md-2 book-img">
            <a href="" class="book-link"><img src="bookimages/The_Washington_Monument.jpg" class="img-responsive book"></a>
        </div>
        <div class="col-xs-4 col-md-2 book-img">
            <a href="" class="book-link"><img src="bookimages/Charlie_Bone_and_the_Hidden_King.jpg" class="img-responsive book"></a>
        </div>
        <div class="col-xs-4 col-md-2 book-img">
            <a href="" class="book-link"><img src="bookimages/The_Washington_Monument.jpg" class="img-responsive book"></a>
        </div>
        <div class="col-xs-12 shelf hidden-md hidden-lg"></div>

        <div class="col-xs-4 col-md-2 book-img">
            <a href="" class="book-link"><img src="bookimages/Charlie_Bone_and_the_Hidden_King.jpg" class="img-responsive book"></a>
        </div>
        <div class="col-xs-4 col-md-2 book-img">
            <a href="" class="book-link"><img src="bookimages/The_Washington_Monument.jpg" class="img-responsive book"></a>
        </div>
        <div class="col-xs-4 col-md-2 book-img">
            <a href="" class="book-link"><img src="bookimages/Charlie_Bone_and_the_Hidden_King.jpg" class="img-responsive book"></a>
        </div>
        <div class="col-xs-12 shelf"></div>



    </div>
    </div>
</div>
