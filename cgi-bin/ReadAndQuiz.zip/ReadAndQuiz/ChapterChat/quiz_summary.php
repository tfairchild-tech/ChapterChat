<br><br>
<div class="container container-fluid">
    <div class="chapterchat-question">
        <label class="radio control-label">This is a question? </label>
        <div class="radio">
            <label><input type="radio" name="optradio">Option 1</label>
        </div>
        <div class="radio">
            <label><input type="radio" name="optradio">Option 2</label>
        </div>
        <div class="radio disabled">
            <label><input type="radio" name="optradio">Option 3</label>
        </div>
        <div class="radio">
            <label><input type="radio" name="optradio">Option 4</label>
        </div>
    </div>
    <br>
    <div class="chapterchat-question">
        <label class="radio control-label">This is another question? </label>
        <div class="radio">
            <label><input type="radio" name="optradio">Option 1</label>
        </div>
        <div class="radio">
            <label><input type="radio" name="optradio">Option 2</label>
        </div>
        <div class="radio disabled">
            <label><input type="radio" name="optradio">Option 3</label>
        </div>
        <div class="radio">
            <label><input type="radio" name="optradio">Option 4</label>
        </div>
    </div>

</div>