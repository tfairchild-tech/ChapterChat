<footer class="footer">
    <div class="container text-center">
        <p class="text-muted chapterchat-font-footer">Chapter Chat
            <a class="page-scroll chapterchat-font-top" href="#" data-toggle="modal" data-target="#adminModal" ><img src="assets/favicon-16x16.png"></a>
            Copyright &copy;2017<br>Lina Haddad &amp; Traci Fairchild</p>
    </div>
</footer>

</body>
</html>

