<?php include 'header.php';?>

     <section id="ChapterChatMain" name="ChapterChatMain">
        <div class="container">
            <div class="row">
                <div >
                    <?php
                    if (isset($_SESSION["logintype"])) {
                        if ($_SESSION["logintype"] == 0) {
                            echo "<script> window.location.replace('studentHome.php') </script>";
                        } else {
                            echo "<script> window.location.replace('teacherHome.php') </script>";
                        }
                    }
                    if (isset($_SESSION["badpassword"]) == 1) {
                        unset($_SESSION['badpassword']);
                        echo "<script>$('#registerModal').modal('show');</script>";
                    }
                    ?>

                </div>
            </div>
        </div>
    </section>

<?php include 'footer.php';?>
