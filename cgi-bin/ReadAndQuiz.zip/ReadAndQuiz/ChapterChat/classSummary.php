<?php
/**
 * Created by PhpStorm.
 * User: tf3581
 * Date: 4/2/2017
 * Time: 7:08 PM
 */
if (!isset($_GET['grade'])) {
    $grade = $_GET['grade'];
}
?>



names for grade <?php echo $grade; ?> here