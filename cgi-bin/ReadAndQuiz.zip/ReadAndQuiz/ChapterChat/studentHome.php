<?PHP include 'requirestudent.php'; ?>
<?php include 'header.php';

	include('db_connect.php');
	ini_set('display_errors', 1);
	ini_set('display_startup_errors', 1);
	error_reporting(E_ALL);
	$thisyear= date("Y");
	$call = mysqli_prepare($conn, 'CALL ReadEdu.GetQuizHistory(?,?)');
	mysqli_stmt_bind_param($call, 'ii', $_SESSION["SCId"],$thisyear);
	mysqli_stmt_execute($call);
	$result = $call ->get_result();
	/*
	$history='<ul>';
	$counter=1;
	while ($row = $result->fetch_assoc() or $counter<=4) {
		//$history=$history. '<li>';
		//$history=$history. $row['DateOfQuiz'] ." <a href='quizReflection.php?studentQuizId=".$row['StudentQuizId']."'>".$row['BookTitle'] .'</a> '. $row['numCorrectQuestions'].'/'.$row['numOfQuestions'];
		//$history=$history. '</li>';
		
		$history=$history. '<li>';
		$history=$history.'<b style="font-size:10pt"><a href="quizReflection.php?studentQuizId='.$row['StudentQuizId'].'&viewOnly=1">'.$row['BookTitle'].'</a> ';
		$history=$history.'by '.$row['authorFirstName'].' '.$row['authorLastName'].'</b> ';
		$date=date_create($row['DateOfQuiz']);
		$history=$history.'on '. date_format($date,"F j, Y").' ';	
		if  ($row['Passed']==1)
			$history=$history."<font color='green'><b>";
		else
			$history=$history."<font color='red'><b>";		
		$history=$history.$row['numCorrectQuestions'].'/'.$row['numOfQuestions'].'</b></font>';
		//$history=$history."  <font size='1pt'><a href='quizReflection.php?studentQuizId=".$row['StudentQuizId']."'>Access Quiz</a></font>";
		$history=$history. '</li><br/>';
		$counter= $counter+1;
	}
	$history=$history. '</ul>';
	*/
	
	$history='';
	$counter=1;
	while ($row = $result->fetch_assoc() and $counter<=3) {
		$history=$history. '<a href="#" class="list-group-item">';
		$history=$history.'<b style="font-size:10pt"><span  style="color:blue" onclick=window.location="quizReflection.php?studentQuizId='.$row['StudentQuizId'].'&viewOnly=1">'.$row['BookTitle'].'</span> ';
		$history=$history.'by '.$row['authorFirstName'].' '.$row['authorLastName'].'</b> ';
		$date=date_create($row['DateOfQuiz']);
		$history=$history.'on '. date_format($date,"F j, Y").' ';	
		if  ($row['Passed']==1)
			$history=$history."<font color='green'><b>";
		else
			$history=$history."<font color='red'><b>";		
		$history=$history.$row['numCorrectQuestions'].'/'.$row['numOfQuestions'].'</b></font>';
		//$history=$history."  <font size='1pt'><a href='quizReflection.php?studentQuizId=".$row['StudentQuizId']."'>Access Quiz</a></font>";
		if  ($row['IsPractice']==1)
			$history=$history.'  <span class="label label-success">practice</span>';
		$history=$history. '</a>';
		$counter= $counter+1;
	}
	if ($history == '')
		$history= '<a href="#" class="list-group-item">No Quiz Found</a>';

		
	mysqli_stmt_close($call);
	
	$call = mysqli_prepare($conn, 'CALL ReadEdu.GetStudentSummary(?)');
	mysqli_stmt_bind_param($call, 'i', $_SESSION["SCId"]);
	mysqli_stmt_execute($call);
	$result = $call ->get_result();
	
	$studentSummary='';
	$schoolyear='';
	while ($row = $result->fetch_assoc()) {
		$schoolyear= $row['SchoolYear'];
		$studentSummary=$studentSummary.' <a href="#" class="list-group-item">School Year: '.$row['SchoolYear'].'</a>';
		$studentSummary=$studentSummary.'<a href="#" class="list-group-item">Student Reading Level: '.$row['ReadingLevel'].'</a>'; 

		$studentSummary=$studentSummary. '<a href="#" class="list-group-item">Student Accuracy: <span alt="'.number_format($row['CorrectnessLevel']).'"  class="sparkpie" data-peity="{ &quot;fill&quot;: [&quot;#6EBB1F&quot;, &quot;#eee&quot;]}">'. number_format($row['CorrectnessLevel']).'/100</span></a>';  
		$studentSummary=$studentSummary. '<a href="#" class="list-group-item">Student Total Points: '. number_format($row['EarnedPointsTotal']).' Points.</a>';  
	}
	
	mysqli_stmt_close($call);
	/*
	$call = mysqli_prepare($conn, 'CALL ReadEdu.rptStudentBookLevel(?)');
	mysqli_stmt_bind_param($call, 'i', $_SESSION["SCId"]);
	mysqli_stmt_execute($call);
	$result = $call ->get_result();
	
	$data = array();
	$categories = array();
	while ($row = $result->fetch_assoc()) {
		$categories[] = str_replace("'","",$row['BookTitle']);
		$data[] = $row['BookLevel'];		
	}
	$cat= "'". join($categories, "','")."'";
	*/
	
	$call = mysqli_prepare($conn, 'CALL ReadEdu.rptStudentMonthlyReading(?)');
	mysqli_stmt_bind_param($call, 'i', $_SESSION["SCId"]);
	mysqli_stmt_execute($call);
	$result = $call ->get_result();
	
	$passed = array();
	$failed = array();
	$practice = array();
	$categories = array();
	while ($row = $result->fetch_assoc()) {
		$date=date_create($row['DateOfQuiz']);		
		$categories[] = date_format($date,"M d");
		$passed[] = $row['countPassed'];
		$failed[] = $row['countFailed'];
		$practice[] = $row['countPractice'];		
	}	
	$cat= "'". join($categories, "','")."'";	
	
	mysqli_stmt_close($call);
	
	$call = mysqli_prepare($conn, 'CALL ReadEdu.rptStudentReadingLvl(?)');
	mysqli_stmt_bind_param($call, 'i', $_SESSION["SCId"]);
	mysqli_stmt_execute($call);
	$result = $call ->get_result();
	$readingLvl = array();
	while ($row = $result->fetch_assoc()) {
		$readingLvl[] = $row['weightedavg'];		
	}	
		
	$call->close();	
	include 'db_close.php';
?>

<style>
#studentReport {
	min-width: 310px;
	height: 400px;
	margin: 0 auto
	
}
</style>

<div class="container">
    <div class="jumbotron chapter_chat_jumbotron_test">
            <div class="row center-block">
                
                    <div class="panel" style="width:32%">
                        <div class="panel-heading chapterchat-font-hdr text-center" style="background-image:none;background-color: #2E7B32; color:#7AB142;">Student Summary</div>
                        <div class="list-group" id='StudentSummary'><?php echo($studentSummary) ?></div>
                        <a href="#"><div class="panel-footer"><div class="text-center chapterchat-font chapter-chat-nav-link" href="student_summary.php" data-target="#student" id="studentsummaryLink">View all</div></div></a>
                    </div>
                    <div class="panel panel-info" style="width:32%">
                        <div class="panel-heading chapterchat-font-hdr text-center" style="background-image:none; background-color: #FFCD07; color:#FF8E00;">Quiz History</div>
                        <div class="list-group"><?php echo($history) ?></div>
                        <div class="panel-footer">
							<div class="text-center chapterchat-font chapter-chat-nav-link" data-target="#quiz">
								<a href="bookSearch.php">Take Quiz</a>   /    <a href="StudentQuizSearch.php">View All Quizzes</a>
							</div>
						</div>
						
                    </div>
                    <div class="panel panel-success" style="width:22%">
                        <div class="panel-heading chapterchat-font-hdr text-center" style="background-image:none; background-color: #1565C0; color:#62B3F5;">Book Shelf</div>
                        <div class="list-group"></div>
                        <a href="bookshelf.php"><div class="panel-footer page-scroll"><div class="text-center chapterchat-font chapter-chat-nav-link"  href="bookshelf_summary.php" data-target="#bookshelf" id="bookshelfsummaryLink">View My Books</div></div></a>
                        <a href="bookshelf.php?rlevel=gte"><div class="panel-footer page-scroll"><div class="text-center chapterchat-font chapter-chat-nav-link"  href="bookshelf_summary.php" data-target="#bookshelf" id="bookshelfsummaryLink" title="View books greater than your current reading level">Book Recommendations</div></div></a>

                    </div>
                
            </div>
			<div id="studentReport"></div>
    </div>
</div>

<?php include 'footer.php';?>
<?php if (count($categories)>0) { 
?>
<script src="js/highcharts/highcharts.js"></script>
<script type="text/javascript">
$(document).ready(function() {
/*
		Highcharts.chart('studentReport', {
			title: {
				text: 'Student Books Level ,<?php echo($schoolyear) ?>'
			},
			yAxis: {
				title: {
					text: 'Books Level'
				}
			},
			legend: {
				layout: 'vertical',
				align: 'right',
				verticalAlign: 'middle'
			},

			xAxis: {
				categories: [<?php echo ($cat) ?>]/*,
				plotBands: [{ // visualize the weekend
					from: 4.5,
					to: 6.5,
					color: 'rgba(68, 170, 213, .2)'
				}]*/

		/*	},

			series: [{
				name: 'Books',
				data: [<?php echo join($data, ',') ?>]
			}]
			
			
		});*/
		Highcharts.chart('studentReport', {
			chart: {
				
				marginRight: 80 // like left
			},
			title: {
				text: 'Student Reading Progress Chart'
			},
			xAxis: {
				categories: [<?php echo $cat ?>],
				crosshair: true				
			},
			/*yAxis: {
				min: 0,
				title: {
					text: 'Number Of Quizzes'
				}
			},*/
			yAxis: [{ // Primary yAxis
				labels: {
					style: {
						color: Highcharts.getOptions().colors[0]
					}
				},
				title: {
					text: 'Number Of Quizzes',
					style: {
						color: Highcharts.getOptions().colors[0]
					}
				}
			}, { // Secondary yAxis
				title: {
					text: 'Reading Level',
					style: {
						color: Highcharts.getOptions().colors[3]
					}
				},        								
				opposite: true,
				labels: {
					style: {
						color: Highcharts.getOptions().colors[3]
					}
				}
			}],			
			legend: {
				reversed: true
			},
			plotOptions: {
				series: {
					stacking: 'normal'
				}
			},
			series: [{
				name: 'Passed Test Quiz',
				type: 'column',
				data: [<?php echo join($passed, ',') ?>]
			}, {
				name: 'Failed Test Quiz',
				type: 'column',
				data: [<?php echo join($failed, ',') ?>]
			}, {
				name: 'Practice',
				type: 'column',
				data: [<?php echo join($practice, ',') ?>]
			},{
				name: 'ReadingLevel',
				type: 'spline',
				yAxis:1,
				data: [<?php echo join($readingLvl, ',') ?>]
			}
			
			]
		});		
});

/*
Highcharts.chart('container', {
    chart: {
        zoomType: 'xy'
    },
    title: {
        text: 'Average Monthly Temperature and Rainfall in Tokyo'
    },
    subtitle: {
        text: 'Source: WorldClimate.com'
    },
    xAxis: [{
        categories: ['Jan', 'Feb', 'Mar', 'Apr', 'May', 'Jun',
            'Jul', 'Aug', 'Sep', 'Oct', 'Nov', 'Dec'],
        crosshair: true
    }],
    yAxis: [{ // Primary yAxis
        labels: {
            format: '{value}�C',
            style: {
                color: Highcharts.getOptions().colors[1]
            }
        },
        title: {
            text: 'Temperature',
            style: {
                color: Highcharts.getOptions().colors[1]
            }
        }
    }, { // Secondary yAxis
        title: {
            text: 'Rainfall',
            style: {
                color: Highcharts.getOptions().colors[0]
            }
        },
        labels: {
            format: '{value} mm',
            style: {
                color: Highcharts.getOptions().colors[0]
            }
        },
        opposite: true
    }],
    tooltip: {
        shared: true
    },
    legend: {
        layout: 'vertical',
        align: 'left',
        x: 120,
        verticalAlign: 'top',
        y: 100,
        floating: true,
        backgroundColor: (Highcharts.theme && Highcharts.theme.legendBackgroundColor) || '#FFFFFF'
    },
    series: [{
        name: 'Rainfall',
        type: 'column',
        yAxis: 1,
        data: [49.9, 71.5, 106.4, 129.2, 144.0, 176.0, 135.6, 148.5, 216.4, 194.1, 95.6, 54.4],
        tooltip: {
            valueSuffix: ' mm'
        }

    }, {
        name: 'Temperature',
        type: 'spline',
        data: [7.0, 6.9, 9.5, 14.5, 18.2, 21.5, 25.2, 26.5, 23.3, 18.3, 13.9, 9.6],
        tooltip: {
            valueSuffix: '�C'
        }
    }]
});

*/
</script>

<?php } ?>

<script>
$(".sparkpie").peity("pie", {
	delimeter: "/",
	radius: 8,
	fill: function(value, i, all) {
		var colors
		if (value >= 80) {
			colours = ["green", "#f5f5f5"]
		} else if (value <= 60) {
			colours = ["orange", "#f5f5f5"]
		} else {
			colours = ["red", "#f5f5f5"]
		}
		return colours[i]
	}
});
</script>