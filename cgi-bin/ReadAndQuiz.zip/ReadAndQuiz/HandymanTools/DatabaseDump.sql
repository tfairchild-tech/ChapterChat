CREATE DATABASE  IF NOT EXISTS `handymantools` /*!40100 DEFAULT CHARACTER SET latin1 */;
USE `handymantools`;
-- MySQL dump 10.13  Distrib 5.7.9, for Win64 (x86_64)
--
-- Host: barbados.lno.att.com    Database: handymantools
-- ------------------------------------------------------
-- Server version	5.0.91-community-nt

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Not dumping tablespaces as no INFORMATION_SCHEMA.FILES table on this server
--

--
-- Table structure for table `accessory`
--

DROP TABLE IF EXISTS `accessory`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `accessory` (
  `ToolID` int(11) NOT NULL,
  `AccessoryList` varchar(250) default NULL,
  PRIMARY KEY  (`ToolID`),
  CONSTRAINT `ToolIDacc` FOREIGN KEY (`ToolID`) REFERENCES `tool` (`ToolID`) ON DELETE NO ACTION ON UPDATE NO ACTION
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `clerk`
--

DROP TABLE IF EXISTS `clerk`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `clerk` (
  `Login` varchar(50) NOT NULL,
  `Password` varchar(50) NOT NULL,
  `FirstName` varchar(50) default NULL,
  `LastName` varchar(50) default NULL,
  PRIMARY KEY  (`Login`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `customer`
--

DROP TABLE IF EXISTS `customer`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `customer` (
  `Login` varchar(50) NOT NULL,
  `Password` varchar(50) NOT NULL,
  `FirstName` varchar(50) default NULL,
  `LastName` varchar(50) default NULL,
  `WorkPhone` varchar(45) default NULL,
  `HomePhone` varchar(45) default NULL,
  `Address` varchar(256) default NULL,
  PRIMARY KEY  (`Login`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `reservation`
--

DROP TABLE IF EXISTS `reservation`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `reservation` (
  `ReservationID` int(11) NOT NULL auto_increment,
  `CustomerLogin` varchar(50) default NULL,
  `StartDate` date default NULL,
  `EndDate` date default NULL,
  `CC` varchar(16) default NULL,
  `CCExpiration` varchar(4) default NULL,
  `DropOffClerkLogin` varchar(50) default NULL,
  `DropOffDate` date default NULL,
  `PickUpClerkLogin` varchar(50) default NULL,
  `PickUpDate` date default NULL,
  PRIMARY KEY  (`ReservationID`),
  KEY `CustomerLogin_idx` (`CustomerLogin`),
  KEY `PickUpClerkLogin_idx` (`PickUpClerkLogin`),
  KEY `DropOffClerkLogin_idx` (`DropOffClerkLogin`),
  CONSTRAINT `CustomerLogin` FOREIGN KEY (`CustomerLogin`) REFERENCES `customer` (`Login`) ON DELETE NO ACTION ON UPDATE NO ACTION,
  CONSTRAINT `DropOffClerkLogin` FOREIGN KEY (`DropOffClerkLogin`) REFERENCES `clerk` (`Login`) ON DELETE NO ACTION ON UPDATE NO ACTION,
  CONSTRAINT `PickUpClerkLogin` FOREIGN KEY (`PickUpClerkLogin`) REFERENCES `clerk` (`Login`) ON DELETE NO ACTION ON UPDATE NO ACTION
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `reservedtool`
--

DROP TABLE IF EXISTS `reservedtool`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `reservedtool` (
  `ReservationID` int(11) NOT NULL,
  `ToolID` int(11) NOT NULL,
  PRIMARY KEY  (`ReservationID`,`ToolID`),
  KEY `ToolID_idx` (`ToolID`),
  CONSTRAINT `ReservationID` FOREIGN KEY (`ReservationID`) REFERENCES `reservation` (`ReservationID`) ON DELETE NO ACTION ON UPDATE NO ACTION,
  CONSTRAINT `ToolID` FOREIGN KEY (`ToolID`) REFERENCES `tool` (`ToolID`) ON DELETE NO ACTION ON UPDATE NO ACTION
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Temporary view structure for view `rptclerkpickupdropoffs`
--

DROP TABLE IF EXISTS `rptclerkpickupdropoffs`;
/*!50001 DROP VIEW IF EXISTS `rptclerkpickupdropoffs`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE VIEW `rptclerkpickupdropoffs` AS SELECT 
 1 AS `LastName`,
 1 AS `FirstName`,
 1 AS `PickUps`,
 1 AS `DropOffs`*/;
SET character_set_client = @saved_cs_client;

--
-- Temporary view structure for view `rptlastmonthrentals`
--

DROP TABLE IF EXISTS `rptlastmonthrentals`;
/*!50001 DROP VIEW IF EXISTS `rptlastmonthrentals`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE VIEW `rptlastmonthrentals` AS SELECT 
 1 AS `LastName`,
 1 AS `FirstName`,
 1 AS `Login`,
 1 AS `rentals`*/;
SET character_set_client = @saved_cs_client;

--
-- Temporary view structure for view `rpttotalprofit`
--

DROP TABLE IF EXISTS `rpttotalprofit`;
/*!50001 DROP VIEW IF EXISTS `rpttotalprofit`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE VIEW `rpttotalprofit` AS SELECT 
 1 AS `ToolID`,
 1 AS `AbbrDescription`,
 1 AS `rentalprofit`,
 1 AS `costoftool`*/;
SET character_set_client = @saved_cs_client;

--
-- Table structure for table `serviceorder`
--

DROP TABLE IF EXISTS `serviceorder`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `serviceorder` (
  `ToolID` int(11) NOT NULL,
  `StartDate` date NOT NULL,
  `EndDate` date default NULL,
  `Cost` decimal(10,2) default NULL,
  `ClerkLogin` varchar(50) default NULL,
  PRIMARY KEY  (`ToolID`,`StartDate`),
  KEY `ClerkLogin_idx` (`ClerkLogin`),
  CONSTRAINT `ClerkLogin` FOREIGN KEY (`ClerkLogin`) REFERENCES `clerk` (`Login`) ON DELETE NO ACTION ON UPDATE NO ACTION
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `tool`
--

DROP TABLE IF EXISTS `tool`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `tool` (
  `ToolID` int(11) NOT NULL auto_increment,
  `Category` varchar(45) default NULL,
  `Description` varchar(256) default NULL,
  `AbbrDescription` varchar(50) default NULL,
  `DailyRentalPrice` decimal(10,2) default NULL,
  `DepositAmount` decimal(10,2) default NULL,
  `OrigPurchasePrice` decimal(10,2) default NULL,
  `SellingClerkLogin` varchar(50) default NULL,
  `SoldDate` date default NULL,
  `CreatedClerkLogin` varchar(50) default NULL,
  PRIMARY KEY  (`ToolID`),
  KEY `SellingClerkLogin_idx` (`SellingClerkLogin`),
  KEY `CreatedClerkLogin_idx` (`CreatedClerkLogin`),
  CONSTRAINT `CreatedClerkLogin` FOREIGN KEY (`CreatedClerkLogin`) REFERENCES `clerk` (`Login`) ON DELETE NO ACTION ON UPDATE NO ACTION,
  CONSTRAINT `SellingClerkLogin` FOREIGN KEY (`SellingClerkLogin`) REFERENCES `clerk` (`Login`) ON DELETE NO ACTION ON UPDATE NO ACTION
) ENGINE=InnoDB AUTO_INCREMENT=25 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Temporary view structure for view `toolprofit`
--

DROP TABLE IF EXISTS `toolprofit`;
/*!50001 DROP VIEW IF EXISTS `toolprofit`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE VIEW `toolprofit` AS SELECT 
 1 AS `ToolID`,
 1 AS `AbbrDescription`,
 1 AS `rentalprofit`*/;
SET character_set_client = @saved_cs_client;

--
-- Temporary view structure for view `toolserviceorderstotals`
--

DROP TABLE IF EXISTS `toolserviceorderstotals`;
/*!50001 DROP VIEW IF EXISTS `toolserviceorderstotals`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE VIEW `toolserviceorderstotals` AS SELECT 
 1 AS `toolid`,
 1 AS `totalcost`*/;
SET character_set_client = @saved_cs_client;

--
-- Temporary view structure for view `unavailabletoolsbydate`
--

DROP TABLE IF EXISTS `unavailabletoolsbydate`;
/*!50001 DROP VIEW IF EXISTS `unavailabletoolsbydate`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE VIEW `unavailabletoolsbydate` AS SELECT 
 1 AS `toolid`,
 1 AS `startdate`,
 1 AS `enddate`,
 1 AS `status`*/;
SET character_set_client = @saved_cs_client;

--
-- Dumping routines for database 'handymantools'
--
/*!50003 DROP PROCEDURE IF EXISTS `addServiceOrder` */;
--
-- WARNING: old server version. The following dump may be incomplete.
--
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'STRICT_TRANS_TABLES,NO_AUTO_CREATE_USER' */ ;
DELIMITER ;;
CREATE DEFINER=`root`@`%` PROCEDURE `addServiceOrder`(
	IN tool_ID int,
	IN startDate Date,
	IN endDate Date,
	IN cost decimal(10,2),
	IN clerk varchar(50)
)
BEGIN
	DECLARE avlCount int;
    DECLARE successFlag int DEFAULT 0;
	
	SELECT count(*) INTO avlCount FROM tool t  
		WHERE t.toolID not in (       
			SELECT toolid
				FROM unavailableToolsByDate ut
				WHERE ut.startdate <=endDate  and ut.enddate >= startDate
		)
		and t.toolID=tool_ID;
		
		IF avlCount > 0 THEN
			BEGIN
				INSERT INTO handymantools.serviceorder
				(`ToolID`,
				`StartDate`,
				`EndDate`,
				`Cost`,
				`ClerkLogin`)
				VALUES
				(tool_ID,
				startDate,
				endDate,
				cost,
				clerk);
				SET successFlag = 1;
		    END;
		END IF;
		SELECT successFlag;#Return 1 if the order was successful or 0 if it was unavailable
END ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 DROP PROCEDURE IF EXISTS `createReservation` */;
--
-- WARNING: old server version. The following dump may be incomplete.
--
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'STRICT_TRANS_TABLES,NO_AUTO_CREATE_USER' */ ;
DELIMITER ;;
CREATE DEFINER=`root`@`%` PROCEDURE `createReservation`(
	IN toolIDList varchar(100),
    IN startDate date,
    IN endDate date,
    IN custLogin varchar(50)
)
BEGIN
	DECLARE curID int;
    DECLARE numToolsAvail int DEFAULT 0;
    DECLARE numTools int DEFAULT 0;
    DECLARE reservationID int DEFAULT -1;
	
	START TRANSACTION;
        #Create Temporary Reservation Table
		CREATE TEMPORARY TABLE IF NOT EXISTS reservedtools
        (ToolID int(11) NOT NULL);
        
		SET @values = REPLACE(toolIDList, ',', '),(');
		SET @values = CONCAT('(', @values, ')');
		SET @insert = CONCAT('INSERT INTO reservedtools VALUES ', @values);
		PREPARE stmt FROM @insert;
		EXECUTE stmt;
		DEALLOCATE PREPARE stmt;
        
        #Set number of tools we're attempting to reserve
        SELECT count(*) FROM reservedtools INTO numTools;
        #We need to check availability here by joining on the unavailabletoolsbydate view
        SELECT count(*) FROM reservedtools r
        INNER JOIN
			 (SELECT t.toolID FROM tool t
				WHERE t.toolID not in (SELECT toolid
				FROM unavailableToolsByDate ut
				WHERE ut.startdate <=endDate and ut.enddate >= startdate
                )
			)u
		ON r.ToolID = u.toolid
        INTO numToolsAvail;
        
        #All of the tools we are reserving should match the number of Tools available
        IF numToolsAvail = numTools THEN
			BEGIN
				#Insert our reservation
				INSERT INTO handymantools.reservation
					(`CustomerLogin`,	`StartDate`,	`EndDate`)
				VALUES
					(custLogin,			startDate,		endDate);

				#Set so we can return it to the stored proc   
				SET reservationID = last_insert_ID();
                
				# Cross join reservation with temp table tools
                INSERT INTO `handymantools`.`reservedtool`
						(`ReservationID`,
						`ToolID`)
				select reservationID, ToolID
				from reservedtools;
                
			END;
        END IF;
        DROP TABLE reservedtools;#drop our temp table
    COMMIT;
    #If our reservation was successful, reservationID > 0 else -1
    SELECT reservationID;
END ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 DROP PROCEDURE IF EXISTS `getAllReservations` */;
--
-- WARNING: old server version. The following dump may be incomplete.
--
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'STRICT_TRANS_TABLES,NO_AUTO_CREATE_USER' */ ;
DELIMITER ;;
CREATE DEFINER=`root`@`%` PROCEDURE `getAllReservations`()
BEGIN
SELECT `reservation`.`ReservationID`,
    `reservation`.`CustomerLogin`,
    `reservation`.`StartDate`,
    `reservation`.`EndDate`,
    `reservation`.`CC`,
    `reservation`.`CCExpiration`,
    `reservation`.`DropOffClerkLogin`,
    `reservation`.`DropOffDate`,
    `reservation`.`PickUpClerkLogin`,
    `reservation`.`PickUpDate`
FROM `handymantools`.`reservation`;
END ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 DROP PROCEDURE IF EXISTS `getAllTools` */;
--
-- WARNING: old server version. The following dump may be incomplete.
--
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'STRICT_TRANS_TABLES,NO_AUTO_CREATE_USER' */ ;
DELIMITER ;;
CREATE DEFINER=`root`@`%` PROCEDURE `getAllTools`()
BEGIN
	SELECT `tool`.`ToolID`,
    `tool`.`Category`,
    `tool`.`Description`,
    `tool`.`AbbrDescription`,
    `tool`.`DailyRentalPrice`,
    `tool`.`DepositAmount`,    
    `tool`.`OrigPurchasePrice`,
    `tool`.`SellingClerkLogin`,
    `tool`.`SoldDate`,
    `tool`.`CreatedClerkLogin`
FROM `handymantools`.`tool`;
END ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 DROP PROCEDURE IF EXISTS `getAuthentication` */;
--
-- WARNING: old server version. The following dump may be incomplete.
--
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'STRICT_TRANS_TABLES,NO_AUTO_CREATE_USER' */ ;
DELIMITER ;;
CREATE DEFINER=`root`@`%` PROCEDURE `getAuthentication`(
Login varchar(50),
Password varchar(50)
)
BEGIN
	select 1;
END ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 DROP PROCEDURE IF EXISTS `getClerkAuthentication` */;
--
-- WARNING: old server version. The following dump may be incomplete.
--
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'STRICT_TRANS_TABLES,NO_AUTO_CREATE_USER' */ ;
DELIMITER ;;
CREATE DEFINER=`root`@`%` PROCEDURE `getClerkAuthentication`(
IN pLogin varchar(50),
IN pPassword varchar(50)
)
BEGIN
	select count(*) cnt
    from clerk
    where login=pLogin and password=pPassword
    ;
END ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 DROP PROCEDURE IF EXISTS `getClerks` */;
--
-- WARNING: old server version. The following dump may be incomplete.
--
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'STRICT_TRANS_TABLES,NO_AUTO_CREATE_USER' */ ;
DELIMITER ;;
CREATE DEFINER=`root`@`%` PROCEDURE `getClerks`()
BEGIN
	select concat(FirstName, ' ',Lastname) as name, login
	from clerk;
END ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 DROP PROCEDURE IF EXISTS `getCustomerAuthentication` */;
--
-- WARNING: old server version. The following dump may be incomplete.
--
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'STRICT_TRANS_TABLES,NO_AUTO_CREATE_USER' */ ;
DELIMITER ;;
CREATE DEFINER=`root`@`%` PROCEDURE `getCustomerAuthentication`(
IN pLogin varchar(50),
IN pPassword varchar(50)
)
BEGIN
	select count(*) cnt, password pw
    from customer
    where login=pLogin
    ;
END ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 DROP PROCEDURE IF EXISTS `getCustomerInfo` */;
--
-- WARNING: old server version. The following dump may be incomplete.
--
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'STRICT_TRANS_TABLES,NO_AUTO_CREATE_USER' */ ;
DELIMITER ;;
CREATE DEFINER=`root`@`%` PROCEDURE `getCustomerInfo`(IN cLogin varchar(50))
BEGIN
	SELECT Login,
		Password,
		FirstName,
		LastName,
		WorkPhone,
		HomePhone,
		Address
FROM Customer
where Login=cLogin;
END ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 DROP PROCEDURE IF EXISTS `getCustomerReservationHistory` */;
--
-- WARNING: old server version. The following dump may be incomplete.
--
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'STRICT_TRANS_TABLES,NO_AUTO_CREATE_USER' */ ;
DELIMITER ;;
CREATE DEFINER=`root`@`%` PROCEDURE `getCustomerReservationHistory`(IN cLogin varchar(50))
BEGIN
	SELECT  r.ReservationID,r.CustomerLogin,
            DATE_FORMAT(r.StartDate,'%m-%d-%Y') as StartDate,
            DATE_FORMAT(r.EndDate,'%m-%d-%Y') as EndDate,
			c1.FirstName as PickUpClerk,
            c2.FirstName as DropOffClerk,
			GROUP_CONCAT(t.AbbrDescription SEPARATOR ', ') as tools,
            sum(t.DailyRentalPrice * (r.EndDate - r. StartDate)) as DailyRentalPrice, 
            sum(t.DepositAmount) as DepositAmount
	FROM reservation AS r
	LEFT JOIN Clerk AS c1 on r.pickUpClerkLogin = c1.Login
	LEFT JOIN Clerk AS c2 on r.dropOffClerkLogin = c2.Login
	INNER JOIN reservedtool AS rt ON r.reservationID = rt.reservationID
	INNER JOIN tool AS t on rt.ToolID = t.ToolID
	WHERE r.CustomerLogin = cLogin
	Group by r.ReservationID, r.ReservationID,r.CustomerLogin, r.StartDate,r.EndDate,
	c1.FirstName, c2.FirstName
	ORDER BY r.ReservationID desc;
END ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 DROP PROCEDURE IF EXISTS `getCustomers` */;
--
-- WARNING: old server version. The following dump may be incomplete.
--
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'STRICT_TRANS_TABLES,NO_AUTO_CREATE_USER' */ ;
DELIMITER ;;
CREATE DEFINER=`root`@`%` PROCEDURE `getCustomers`()
BEGIN
	SELECT `customer`.`Login`,
    `customer`.`Password`,
    `customer`.`FirstName`,
    `customer`.`LastName`,
    `customer`.`WorkPhone`,
    `customer`.`HomePhone`,
    `customer`.`Address`
FROM `handymantools`.`customer`;
END ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 DROP PROCEDURE IF EXISTS `getReservationInfo` */;
--
-- WARNING: old server version. The following dump may be incomplete.
--
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'STRICT_TRANS_TABLES,NO_AUTO_CREATE_USER' */ ;
DELIMITER ;;
CREATE DEFINER=`root`@`%` PROCEDURE `getReservationInfo`(IN resID int)
BEGIN
	SELECT customerlogin, 
			CONCAT(Customer.firstname ,' ', Customer.lastname) as CustomerName ,
			startdate,
			enddate, 
			cc, 
			CONCAT(pc.firstname, ' ',pc.Lastname) as PickupClerkName,
             DATE_FORMAT(PickUpDate,'%m-%d-%Y')  as PickUpDate,
            CONCAT(dc.firstname, ' ',dc.Lastname) as dropOffClerkName,
			 DATE_FORMAT(DropOffDate,'%m-%d-%Y')  as DropOffDate
	FROM reservation
	Inner join Customer on Customer.login = reservation.customerlogin
	left join Clerk pc on pc.login = reservation.pickupClerkLogin
    left join Clerk dc on dc.login = reservation.DropOffClerkLogin
	WHERE reservationID = resID;

END ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 DROP PROCEDURE IF EXISTS `getReservationTools` */;
--
-- WARNING: old server version. The following dump may be incomplete.
--
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'STRICT_TRANS_TABLES,NO_AUTO_CREATE_USER' */ ;
DELIMITER ;;
CREATE DEFINER=`root`@`%` PROCEDURE `getReservationTools`(IN resID int)
BEGIN
	SELECT t.ToolID, t.AbbrDescription, t.DailyRentalPrice, t.DepositAmount
	FROM reservedtool AS rtool
	Inner join tool AS t on t.toolID = rtool.toolID
	WHERE rtool.reservationID = resID;

END ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 DROP PROCEDURE IF EXISTS `getReservationTotals` */;
--
-- WARNING: old server version. The following dump may be incomplete.
--
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'STRICT_TRANS_TABLES,NO_AUTO_CREATE_USER' */ ;
DELIMITER ;;
CREATE DEFINER=`root`@`%` PROCEDURE `getReservationTotals`(IN resID int)
BEGIN
	SELECT SUM(t.DailyRentalPrice * (r.EndDate - r. StartDate)) as totalRental , SUM(t.DepositAmount) as TotalDeposit
	FROM reservedtool AS rtool
	Inner join tool AS t on t.toolID = rtool.toolID
    inner join reservation r on r.reservationID= rtool. reservationID
	WHERE rtool.reservationID = resID;

END ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 DROP PROCEDURE IF EXISTS `insertCustomer` */;
--
-- WARNING: old server version. The following dump may be incomplete.
--
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'STRICT_TRANS_TABLES,NO_AUTO_CREATE_USER' */ ;
DELIMITER ;;
CREATE DEFINER=`root`@`%` PROCEDURE `insertCustomer`(
IN pLogin varchar(50),
IN pPassword varchar(50),
IN pFirstName varchar(50),
IN pLastName varchar(50),
IN pWorkPhone varchar(45),
IN pHomePhone varchar(45),
IN pAddress varchar(256)	
)
BEGIN

INSERT INTO `handymantools`.`customer`
(`Login`,
`Password`,
`FirstName`,
`LastName`,
`WorkPhone`,
`HomePhone`,
`Address`)
VALUES
	(pLogin,
	pPassword,
	pFirstName,
	pLastName,
	pWorkPhone,
	pHomePhone,
	pAddress);

END ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 DROP PROCEDURE IF EXISTS `insertTool` */;
--
-- WARNING: old server version. The following dump may be incomplete.
--
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'STRICT_TRANS_TABLES,NO_AUTO_CREATE_USER' */ ;
DELIMITER ;;
CREATE DEFINER=`root`@`%` PROCEDURE `insertTool`(
	IN toolType varchar(45),
	IN description varchar(256),
	IN abbrDesc varchar(50),
	IN rentalPrice decimal(10,2),
	IN deposit decimal(10,2),
	IN purchasePrice decimal(10,2),
	IN clerk varchar(50),
	IN acc varchar(250)
)
BEGIN
	START TRANSACTION;
		INSERT INTO `handymantools`.`tool`
		(
		`Category`,
		`Description`,
		`AbbrDescription`,
		`DailyRentalPrice`,
		`DepositAmount`,		
		`OrigPurchasePrice`,
		`SellingClerkLogin`,
		`SoldDate`,
		`CreatedClerkLogin`)
		VALUES (
		toolType,
		description,
		abbrDesc,
		rentalPrice,
		deposit,	
		purchasePrice,
		NULL,
		NULL,
		clerk);

		IF toolType = 'Power Tools' THEN
			BEGIN
				INSERT INTO `handymantools`.`accessory`
				(`ToolID`,
				`AccessoryList`)
				VALUES
				(last_insert_id(),
				acc);
			END;
		END  IF;
	COMMIT;
END ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 DROP PROCEDURE IF EXISTS `sellTool` */;
--
-- WARNING: old server version. The following dump may be incomplete.
--
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'STRICT_TRANS_TABLES,NO_AUTO_CREATE_USER' */ ;
DELIMITER ;;
CREATE DEFINER=`root`@`%` PROCEDURE `sellTool`(
	IN tool_ID int,
    IN clerk varchar(50)#,
    #OUT salePrice decimal(10,2)
)
BEGIN
	DECLARE salePrice decimal(10,2);
	DECLARE tStatus int;
    SET salePrice = -1.00;
	START TRANSACTION;
	
    /*
    SELECT status INTO tStatus
	FROM handymantools.tool
	WHERE toolID = tool_ID;
    */
    SELECT count(*) INTO tStatus FROM tool t  
	WHERE t.toolID not in (       
	SELECT toolid
		FROM unavailableToolsByDate ut
		WHERE ut.startdate <='9999-12-31' and ut.enddate >=CURDATE()
		)
    and t.toolID=tool_ID;
    
    IF tStatus > 0 THEN
		BEGIN
			UPDATE handymantools.tool
            SET 
				sellingClerkLogin = clerk,
                SoldDate = CURDATE()
            WHERE toolID = tool_ID;
            
            SELECT OrigPurchasePrice/2 INTO salePrice
			FROM handymantools.tool
			WHERE toolID = tool_ID;
            
        END;
    END IF;
	SELECT salePrice;
	COMMIT;
   
END ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 DROP PROCEDURE IF EXISTS `startfromscratch` */;
--
-- WARNING: old server version. The following dump may be incomplete.
--
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'STRICT_TRANS_TABLES,NO_AUTO_CREATE_USER' */ ;
DELIMITER ;;
CREATE DEFINER=`root`@`%` PROCEDURE `startfromscratch`()
BEGIN
	truncate table reservedtool;
	truncate table reservation;
	truncate table serviceorder;
	update tool
	set sellingclerklogin=null,
	solddate=null,
	createdclerklogin=null;
END ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 DROP PROCEDURE IF EXISTS `updateDropOffInfo` */;
--
-- WARNING: old server version. The following dump may be incomplete.
--
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'STRICT_TRANS_TABLES,NO_AUTO_CREATE_USER' */ ;
DELIMITER ;;
CREATE DEFINER=`root`@`%` PROCEDURE `updateDropOffInfo`(
	IN resID int,
    IN clerckLogin varchar(50)
)
BEGIN
 
        UPDATE reservation
		SET 
			DropOffClerkLogin =clerckLogin,
			DropOffDate=CURDATE()
		WHERE reservationID=resID;
	    		
END ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 DROP PROCEDURE IF EXISTS `updatePickUpInfo` */;
--
-- WARNING: old server version. The following dump may be incomplete.
--
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'STRICT_TRANS_TABLES,NO_AUTO_CREATE_USER' */ ;
DELIMITER ;;
CREATE DEFINER=`root`@`%` PROCEDURE `updatePickUpInfo`(
	IN resID int,
    IN ccnum varchar(20),
    IN ccexpire varchar(4),
    IN clerckLogin varchar(50)
)
BEGIN

        UPDATE reservation
		SET cc=ccnum,
			ccexpiration=ccexpire,
			pickupclerklogin=clerckLogin,
			pickupdate=CURDATE()
		WHERE reservationID=resID;
    
END ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;

--
-- Final view structure for view `rptclerkpickupdropoffs`
--

/*!50001 DROP VIEW IF EXISTS `rptclerkpickupdropoffs`*/;
/*!50001 CREATE ALGORITHM=UNDEFINED DEFINER=`root`@`%` SQL SECURITY DEFINER VIEW `rptclerkpickupdropoffs` AS select `c`.`LastName` AS `LastName`,`c`.`FirstName` AS `FirstName`,count(distinct `pu`.`ReservationID`) AS `PickUps`,count(distinct `dr`.`ReservationID`) AS `DropOffs` from ((`clerk` `c` left join `reservation` `pu` on(((`c`.`Login` = `pu`.`PickUpClerkLogin`) and (month(now()) = month(`pu`.`PickUpDate`)) and (year(now()) = year(`pu`.`PickUpDate`))))) left join `reservation` `dr` on(((`c`.`Login` = `dr`.`DropOffClerkLogin`) and (month(now()) = month(`dr`.`DropOffDate`)) and (year(now()) = year(`dr`.`DropOffDate`))))) group by `c`.`LastName`,`c`.`FirstName` order by (count(`pu`.`ReservationID`) + count(`dr`.`ReservationID`)) desc */;

--
-- Final view structure for view `rptlastmonthrentals`
--

/*!50001 DROP VIEW IF EXISTS `rptlastmonthrentals`*/;
/*!50001 CREATE ALGORITHM=UNDEFINED DEFINER=`root`@`%` SQL SECURITY DEFINER VIEW `rptlastmonthrentals` AS select `c`.`LastName` AS `LastName`,`c`.`FirstName` AS `FirstName`,`c`.`Login` AS `Login`,sum((`r`.`EndDate` - `r`.`StartDate`)) AS `rentals` from (`customer` `c` join `reservation` `r` on((`c`.`Login` = `r`.`CustomerLogin`))) where (`r`.`EndDate` between date_format((now() - interval 1 month),_utf8'%Y-%m-01 00:00:00') and date_format(last_day((now() - interval 1 month)),_utf8'%Y-%m-%d 23:59:59')) group by `c`.`LastName`,`c`.`FirstName`,`c`.`Login` */;

--
-- Final view structure for view `rpttotalprofit`
--

/*!50001 DROP VIEW IF EXISTS `rpttotalprofit`*/;
/*!50001 CREATE ALGORITHM=UNDEFINED DEFINER=`root`@`%` SQL SECURITY DEFINER VIEW `rpttotalprofit` AS select `p`.`ToolID` AS `ToolID`,`p`.`AbbrDescription` AS `AbbrDescription`,`p`.`rentalprofit` AS `rentalprofit`,(`t`.`OrigPurchasePrice` + ifnull(`so`.`totalcost`,0)) AS `costoftool` from ((`toolprofit` `p` join `tool` `t` on((`p`.`ToolID` = `t`.`ToolID`))) left join `toolserviceorderstotals` `so` on((`p`.`ToolID` = `so`.`toolid`))) */;

--
-- Final view structure for view `toolprofit`
--

/*!50001 DROP VIEW IF EXISTS `toolprofit`*/;
/*!50001 CREATE ALGORITHM=UNDEFINED DEFINER=`root`@`%` SQL SECURITY DEFINER VIEW `toolprofit` AS select `t`.`ToolID` AS `ToolID`,`t`.`AbbrDescription` AS `AbbrDescription`,sum((`t`.`DailyRentalPrice` * (`r`.`EndDate` - `r`.`StartDate`))) AS `rentalprofit` from ((`tool` `t` left join `reservedtool` `rt` on((`t`.`ToolID` = `rt`.`ToolID`))) left join `reservation` `r` on((`rt`.`ReservationID` = `r`.`ReservationID`))) where (isnull(`t`.`SoldDate`) and (`r`.`PickUpDate` is not null)) group by `t`.`ToolID`,`t`.`AbbrDescription` */;

--
-- Final view structure for view `toolserviceorderstotals`
--

/*!50001 DROP VIEW IF EXISTS `toolserviceorderstotals`*/;
/*!50001 CREATE ALGORITHM=UNDEFINED DEFINER=`root`@`%` SQL SECURITY DEFINER VIEW `toolserviceorderstotals` AS select `t`.`ToolID` AS `toolid`,sum(`s`.`Cost`) AS `totalcost` from (`tool` `t` join `serviceorder` `s` on((`t`.`ToolID` = `s`.`ToolID`))) group by `t`.`ToolID` */;

--
-- Final view structure for view `unavailabletoolsbydate`
--

/*!50001 DROP VIEW IF EXISTS `unavailabletoolsbydate`*/;
/*!50001 CREATE ALGORITHM=UNDEFINED DEFINER=`root`@`%` SQL SECURITY DEFINER VIEW `unavailabletoolsbydate` AS select `t`.`ToolID` AS `toolid`,`r`.`StartDate` AS `startdate`,`r`.`EndDate` AS `enddate`,_utf8'reserved' AS `status` from ((`tool` `t` left join `reservedtool` `rt` on((`t`.`ToolID` = `rt`.`ToolID`))) left join `reservation` `r` on((`rt`.`ReservationID` = `r`.`ReservationID`))) where (`r`.`StartDate` is not null) union select `t`.`ToolID` AS `toolid`,`s`.`StartDate` AS `startdate`,`s`.`EndDate` AS `enddate`,_utf8'out for service' AS `status` from (`tool` `t` left join `serviceorder` `s` on((`t`.`ToolID` = `s`.`ToolID`))) where (`s`.`StartDate` is not null) union select `tool`.`ToolID` AS `ToolID`,`tool`.`SoldDate` AS `solddate`,cast(_utf8'9999-12-31' as date) AS `enddate`,_utf8'sold' AS `sold` from `tool` order by `toolid`,`startdate` */;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2016-04-17 13:08:35
