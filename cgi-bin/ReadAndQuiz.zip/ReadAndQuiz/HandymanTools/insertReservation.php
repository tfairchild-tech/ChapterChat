<?php
	$reservationID="";
	include 'requirecustomer.php';   
	include('db_connect.php');	
	$email= $_SESSION["login"];
	$result = mysqli_query($conn, "call handymantools.createReservation('" . $_GET["toolIDs"] ."', '". $_GET["startDate"] ."', '" .$_GET["endDate"]. "', '" . $email . "')");
	while($row = $result->fetch_assoc()) {	
		$reservationID= $row["reservationID"];
	}
	mysqli_free_result($result);	
	echo $reservationID;
?>