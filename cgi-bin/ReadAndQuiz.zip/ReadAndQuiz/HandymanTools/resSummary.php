<?php
	include 'requirecustomer.php';
	$i = 1;
	$toolIDs= "";
	while($i <= $_POST["numOfTools"]) {
		$toolIDs= $toolIDs . "," . $_POST["tool".$i];
		$i++;
	} 
?>
<?PHP include 'functions.php'; ?>
<!DOCTYPE html>
<html lang="en">
  <head>
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <!-- The above 3 meta tags *must* come first in the head; any other head content must come *after* these tags -->
    <meta name="description" content="">
    <meta name="author" content="">
	<title id="titleText">Reservation Summary</title>
    <script src="https://ajax.googleapis.com/ajax/libs/jquery/1.12.0/jquery.min.js"></script>
    <script src="./bootstrap/js/bootstrap.min.js"></script>
    <!-- Bootstrap core CSS -->
    <link href="bootstrap/css/bootstrap.min.css" rel="stylesheet">
    <!-- Custom styles for this template -->
    <link href="bootstrap/css/jumbotron-narrow.css" rel="stylesheet">
  </head>
	<script  type="text/javascript">
		function insertRes(startDate, endDate, toolsList ){					
			//document.write( 'insertReservation.php?startDate='+startDate+'&endDate='+endDate+'&toolIDs='+toolsList+'&r='+Math.random());
			$.ajax({
				type: "POST",
				dataType: "text",
				url: 'insertReservation.php?startDate='+startDate+'&endDate='+endDate+'&toolIDs='+toolsList+'&r='+Math.random(),
				success: function(myresponse){					
					$("#h2Text").html("Your Reservation Number is " +myresponse);
					$("#titleText").html("Reservation Final");
					$("#submitTr").css("display" ,"none");
					$("#backTr").css("display" ,"");
				},
				error: function(){
					alert("An error has occurred, Please try again later.");		
				}
			});			
		
		}
	</script>  
   <div class="container">
      <div class="header clearfix">
        <nav>
          <ul class="nav nav-pills pull-right">
            <li role="presentation" class="active"><a href="custmainmenu.php">Home</a></li>
            <li role="presentation"><a href="#" data-toggle="modal" data-target="#myModal">About</a></li>
            <li role="presentation"><a href="logout.php">Logout</a></li>
          </ul>
        </nav>
        <h3 class="text-muted">Handyman Tools</h3>
      </div>

		<div class="jumbotron"> 
			<div class="container"><h2 id='h2Text'>Reservation Summary</h2></div>
		
		<table>                       			
			<tr style='height:40px'><th>Tools Desired</th></tr>
			<tr><td align='left'><?php echo $_POST["selectedItems"]  ?></td></tr>
			<tr style='height:30px'><td align='left'><b>Start Date:</b> <?php echo $_POST["startDate"]  ?></td></tr>
			<tr style='height:30px'><td align='left'><b>End Date:</b> <?php echo $_POST["endDate"]  ?></td></tr>
			<tr style='height:30px'><td align='left'><b>Total Rental Price:</b> <?php echo asDollars(floatval($_POST["totalRental"]))  ?></td></tr>
			<tr style='height:30px'><td align='left'><b>Total Deposit Required:</b> <?php echo asDollars(floatval($_POST["totalDeposit"]))   ?></td></tr>
			<tr style='height:40px' id='submitTr'>
				<td align='center'>
					<button type="button"  class="btn btn-sm btn-success" style='width:200px' onclick="insertRes('<?php echo $_POST["startDate"]?>','<?php echo $_POST["endDate"]?>','<?php echo ltrim($toolIDs, ',') ?>')" >Submit</button>&nbsp;&nbsp;
					<button type="button" class="btn btn-sm btn-success" style='width:200px' onclick="window.location='makereservation.php'"  >Reset</button>
				</td>
			</tr>
			<tr style='height:40px; display:none' id='backTr'>
				<td align='center'>
					<button  type="button" class="btn btn-sm btn-success" onclick="window.location='custmainmenu.php'" >Back To The Main Menu</button>
				</td>
			</tr>			
		</table>
	 </div>
		
      <div class="row marketing">
      <footer class="footer">
        <p>&copy; Team 37, Inc.</p>
      </footer>

    <?PHP include 'about.php'; ?>   
    </div> <!-- /container -->
  </body>
</html>		