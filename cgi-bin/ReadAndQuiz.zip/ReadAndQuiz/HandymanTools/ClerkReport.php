<?PHP include 'requireclerk.php'; ?>
<?PHP include 'functions.php'; ?>
<?php

	include 'db_connect.php';
	$sql ="SELECT *, (pickups + dropoffs) as Total FROM handymantools.rptclerkpickupdropoffs;";
	$result = mysqli_query($conn, $sql) or die("Query fail: " . mysqli_error($conn));
	mysqli_close($conn);
    
?>

<!DOCTYPE html>
<html lang="en">
  <head>
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <!-- The above 3 meta tags *must* come first in the head; any other head content must come *after* these tags -->
    <meta name="description" content="">
    <meta name="author" content="">

    <title>Handyman Tools</title>

    <script src="https://ajax.googleapis.com/ajax/libs/jquery/1.12.0/jquery.min.js"></script>
    <script src="./bootstrap/js/bootstrap.min.js"></script>
    <!-- Bootstrap core CSS -->
    <link href="bootstrap/css/bootstrap.min.css" rel="stylesheet">

    <!-- Custom styles for this template -->
    <link href="bootstrap/css/jumbotron-narrow.css" rel="stylesheet">
    
    <!-- HTML5 shim and Respond.js for IE8 support of HTML5 elements and media queries -->
    <!--[if lt IE 9]>
      <script src="https://oss.maxcdn.com/html5shiv/3.7.2/html5shiv.min.js"></script>
      <script src="https://oss.maxcdn.com/respond/1.4.2/respond.min.js"></script>
    <![endif]-->
  </head>

  <body>

    <div class="container">
      <div class="header clearfix">
        <nav>
          <ul class="nav nav-pills pull-right">
            <li role="presentation" class="active"><a href="clerkmainmenu.php">Home</a></li>
            <li role="presentation"><a href="#" data-toggle="modal" data-target="#myModal">About</a></li>
            <li role="presentation"><a href="logout.php">Logout</a></li>
          </ul>
        </nav>
        <h3 class="text-muted">Handyman Tools</h3>
      </div>

      <div class="">
        <p class="lead">
		<h2 class="form-group-heading">Clerk of the Month Report</h2>
		<div class="">
            <table class="table table-striped table-bordered table-hover table-reflow" id ="rentalReportTable">
				<thead class="thead-inverse">
					<tr><th>Clerk</th><th>Pick Ups</th><th>Drop Offs</th><th>Total</th></tr>
				</head>
				<tbody>
				<?php
				while($row = $result->fetch_assoc()) {
					echo "<tr><td>" . $row['FirstName'] . " " . $row['LastName'] . "</td><td>" . $row['PickUps'] . "</td><td>" . $row['DropOffs'] . "</td><td>" . $row['Total'] . "</td></tr>";
				} 
				?>
				</tbody>
			</table>
		</div>
		</p>
      </div>

      <footer class="footer">
        <p>&copy; Team 37, Inc.</p>
      </footer>

      <?PHP include 'about.php'; ?>
    </div> <!-- /container -->
    <script src="./js/functions.js"></script>
	<script type="text/javascript">

	</script>
  </body>
</html>
