<?php	
    include 'functions.php';
	session_start();
    
    if (isset($_SESSION['logintype'])){
        if ($_SESSION['logintype'] != 1)
        {
            $homepage = 'clerkmainmenu.php';
        } 
        else{
            $homepage= 'custmainmenu.php';
        }
    }
    else{
        header( 'Location: ./logout.php' ) ;
    }
    
	if (isset($_POST["inputToolID"])) {
        $tid = $_POST["inputToolID"];
        $sql=" SELECT t.toolID, t.category, t.description, t.abbrDescription, t.dailyRentalPrice, t.DepositAmount, 
					  t.OrigPurchasePrice, t.sellingClerkLogin, t.soldDate, t.createdClerkLogin, a.accessoryList
				 FROM Handymantools.tool t
				LEFT JOIN handymantools.accessory a on t.toolID = a.toolID";
		$sql= $sql . " WHERE t.toolID = ". $tid ;
		//echo $sql;
		$tools="<table class='table table-striped table-bordered'>
		<thead><tr><th>Tool ID</th><th>Description</th><th>Category</th><th>Accessories</th><th>Deposit</th><th>Price/Day</th></tr></thead>";
		include('db_connect.php');	
		$result = mysqli_query($conn, $sql);
		while($row = $result->fetch_assoc()) {
				$tools= $tools . "<tr><td>".$row["toolID"]."</td><td>".$row["description"]."</td><td>".$row["category"]."</td><td>".$row["accessoryList"]."</td><td>".asDollars($row["DepositAmount"])."</td><td>".asDollars($row["dailyRentalPrice"])."</td></tr>";	
				$tname = $row["abbrDescription"];
		}	
		$tools= $tools . "<caption><b>Tool Name:&nbsp;</b>".$tname."</caption></table>";
		// Free result set
		mysqli_free_result($result);	
	} else {
		$tools="<table class='table table-striped table-bordered'>
		<thead><tr><th>Tool ID</th><th>Description</th><th>Category</th><th>Status</th><th>Accessories</th><th>Deposit($)</th><th>Price/Day($)</th></tr></thead>";
		$tools= $tools . "<tr><td colspan=6>Tool ID Not Supplied... please try again.</td></tr></table>";
	}
?>

<!DOCTYPE html>
<html lang="en">
  <head>
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <!-- The above 3 meta tags *must* come first in the head; any other head content must come *after* these tags -->
    <meta name="description" content="">
    <meta name="author" content="">

    <title>Tool Detail</title>

    <script src="https://ajax.googleapis.com/ajax/libs/jquery/1.12.0/jquery.min.js"></script>
    <script src="./bootstrap/js/bootstrap.min.js"></script>
	<!-- JS for DatePicker -->
	<script src="./bootstrap/js/bootstrap-datepicker.min.js"></script>
    <!-- Bootstrap core CSS -->
    <link href="bootstrap/css/bootstrap.min.css" rel="stylesheet">
    <!-- Custom styles for this template -->
    <link href="bootstrap/css/jumbotron-narrow.css" rel="stylesheet">
	<!-- Styles for DatePicker -->
	<link rel="stylesheet" href="bootstrap/css/bootstrap-datepicker.css">    
	
  </head>

  <body>

    <div class="container">
      <div class="header clearfix">
        <nav>
          <ul class="nav nav-pills pull-right">
            <li role="presentation" class="active"><a href="<?=$homepage?>">Home</a></li>
            <li role="presentation"><a href="#" data-toggle="modal" data-target="#myModal">About</a></li>
            <li role="presentation"><a href="logout.php">Logout</a></li>
          </ul>
        </nav>
        <h3 class="text-muted">Handyman Tools</h3>
      </div>

      <div class="jumbotron"> 
		  <div class="container">
			<h2>Tool Detail</h2>
		  </div>
	  </div>		
		<div id="toolDetail">
		<?PHP echo $tools;?>
        </div>
		
        <div class="container text-center">
            <button class="btn btn-lg btn-success" id="mainmenu" name="mainmenu" type="submit" onclick="window.close();">Close</button>
        </div>		
		
      <footer class="footer">
        <p>&copy; Team 37, Inc.</p>
      </footer>

    <?PHP include 'about.php'; ?>   
    </div> <!-- /container -->
  </body>
</html>	