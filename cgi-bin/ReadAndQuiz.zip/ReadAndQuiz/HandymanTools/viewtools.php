<?PHP include 'requireclerk.php'; ?>
<?PHP include 'functions.php'; ?>
<!DOCTYPE html>
<html lang="en">
  <head>
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <!-- The above 3 meta tags *must* come first in the head; any other head content must come *after* these tags -->
    <meta name="description" content="">
    <meta name="author" content="">

    <title>Handyman Tools</title>

    <script src="https://ajax.googleapis.com/ajax/libs/jquery/1.12.0/jquery.min.js"></script>
    <script src="./bootstrap/js/bootstrap.min.js"></script>
    <!-- Bootstrap core CSS -->
    <link href="bootstrap/css/bootstrap.min.css" rel="stylesheet">

    <!-- Custom styles for this template -->
    <link href="bootstrap/css/jumbotron-narrow.css" rel="stylesheet">
    
    <!-- HTML5 shim and Respond.js for IE8 support of HTML5 elements and media queries -->
    <!--[if lt IE 9]>
      <script src="https://oss.maxcdn.com/html5shiv/3.7.2/html5shiv.min.js"></script>
      <script src="https://oss.maxcdn.com/respond/1.4.2/respond.min.js"></script>
    <![endif]-->
  </head>

  <body>

    <div class="container">
      <div class="header clearfix">
        <nav>
          <ul class="nav nav-pills pull-right">
            <li role="presentation" class="active"><a href="<?=$_SESSION['homepage']?>">Home</a></li>
            <li role="presentation"><a href="#" data-toggle="modal" data-target="#myModal">About</a></li>
            <li role="presentation"><a href="logout.php">Logout</a></li>
          </ul>
        </nav>
        <h3 class="text-muted">Handyman Tools</h3>
      </div>

      <div>
        <h1>All Tools Report</h1>
        <table class="table table-bordered">
            <tr>
                <th>ToolID</th>
                <th>Category</th>
                <th>Description</th>
                <th>Abbreviated Description</th>
                <th>Daily Rental Price</th>
                <th>Deposit Amount</th>
                <th>Original Purchase Price</th>
                <th>Created By</th>
                <th>Sold By</th>
                <th>Sold Date</th>
            </tr>
        <?PHP
            include('db_connect.php');
            $result = mysqli_query($conn, "CALL handymantools.getAllTools()") or die("Query fail: " . mysqli_error($conn));
			while($row = $result->fetch_assoc()) {
				echo "<tr>";
                echo "<td>" . $row["ToolID"] . "</td>";
                echo "<td>" . $row["Category"] . "</td>";
                echo "<td>" . $row["Description"] . "</td>";
                echo "<td>" . $row["AbbrDescription"] . "</td>";
                echo "<td>" . asDollars($row["DailyRentalPrice"]) . "</td>";
                echo "<td>" . asDollars($row["DepositAmount"]) . "</td>";
                echo "<td>" . asDollars($row["OrigPurchasePrice"]) . "</td>";
                echo "<td>" . $row["CreatedClerkLogin"] . "</td>";
                echo "<td>" . $row["SellingClerkLogin"] . "</td>";
                echo "<td>" . $row["SoldDate"] . "</td>";
                echo "</tr>";
            }
			 
			
        ?>
        </table>
      </div>

      <footer class="footer">
        <p>&copy; Team 37, Inc.</p>
      </footer>

      <?PHP include 'about.php'; ?>
    </div> <!-- /container -->

    <script src="./js/functions.js"></script>
  </body>
</html>
