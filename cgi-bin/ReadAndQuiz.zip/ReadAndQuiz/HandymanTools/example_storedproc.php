<?php 
    include 'db_connect.php';
    //connect to database

    //run the store proc
    $result = mysqli_query($conn, "CALL handymantools.getClerks") 
    or die("Query fail: " . mysqli_error($conn));

    //loop the result set
    while ($row = mysqli_fetch_array($result)){   
      echo $row["name"];
      echo " (";
      echo $row["login"]; 
      echo ")<br> ";
    }
   include 'db_close.php';
?>
<br>
<br>
<?php
    include 'db_connect.php';
    $result = mysqli_query($conn, "CALL handymantools.getClerkAuthentication('glenn','na')") 
        or die("Query fail: " . mysqli_error($conn));
    echo "Clerks named glenn :";
    while ($row = mysqli_fetch_array($result)){   
        echo $row["cnt"];
    }
 include 'db_close.php';
 ?>