<?php
function asDollars($value) {
	return '$' . number_format($value, 2);
}
?>