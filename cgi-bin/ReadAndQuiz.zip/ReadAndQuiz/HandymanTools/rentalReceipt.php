<?PHP include 'requireclerk.php'; ?>
<?PHP include 'functions.php'; ?>
<?php
	$clerk = $_SESSION["login"];
	$reservationID = $_POST["reservationID"];	
	include 'db_connect.php';
	$clerkName = '';
	$customerName = '';
	$cc = 'Not On File';
	$startDate = '';
	$endDate= '';
	if  ($clerk<>''){
		$result = mysqli_query($conn, "CALL handymantools.updateDropOffInfo('" . $reservationID . "','".$clerk ."')");
		
		$reservationInfo = mysqli_query($conn, "CALL handymantools.getReservationInfo('" . $reservationID . "')");
		while($row = $reservationInfo->fetch_assoc()) {	
			$clerkName = $row["PickupClerkName"];
			$customerName = $row["CustomerName"];
			$cc = $row["cc"];
			$startDate = $row["startdate"];
			$endDate = $row["enddate"];			
		}
		$conn->next_result();	
	}else{
		header( 'Location: ./login.php' ) ;
	
	}
?>

<!DOCTYPE html>
<html lang="en">
  <head>
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <!-- The above 3 meta tags *must* come first in the head; any other head content must come *after* these tags -->
    <meta name="description" content="">
    <meta name="author" content="">
	<title id="titleText">Tools Receipt</title>
    <script src="https://ajax.googleapis.com/ajax/libs/jquery/1.12.0/jquery.min.js"></script>
    <script src="./bootstrap/js/bootstrap.min.js"></script>
    <!-- Bootstrap core CSS -->
    <link href="bootstrap/css/bootstrap.min.css" rel="stylesheet">
    <!-- Custom styles for this template -->
    <link href="bootstrap/css/jumbotron-narrow.css" rel="stylesheet">
  </head>
   <div class="container">
      <div class="header clearfix">
        <nav>
          <ul class="nav nav-pills pull-right">
            <li role="presentation" class="active"><a href="clerkmainmenu.php">Home</a></li>
            <li role="presentation"><a href="#" data-toggle="modal" data-target="#myModal">About</a></li>
            <li role="presentation"><a href="logout.php">Logout</a></li>
          </ul>
        </nav>
        <h3 class="text-muted">Handyman Tools</h3>
      </div>

      <div class="jumbotron"> 	
		<table>                       			
			<tr style='height:40px'><th><h4>HANDYMAN TOOLS RECEIPT<h4></th></tr>
			<tr style='height:30px'>
				<td align='left'><b>Reservation Number:</b> <?php echo $reservationID;  ?></td>
				<td align='left'><b>Clerk on duty:</b> <?php echo $clerkName  ?></td>
			</tr>
			<tr style='height:30px'>
				<td align='left'><b>Customer Name :</b> <?php echo $customerName; ?></td>
				<td align='left'><b>Credit Card# :</b> <?php echo $cc  ?></td>
			</tr>
			<tr style='height:30px'>
				<td align='left'><b>Start Date :</b> <?php echo $startDate; ?></td>
				<td align='left'><b>End Date :</b> <?php echo $endDate  ?></td>
			</tr>			
			
			<tr><td>&nbsp;&nbsp;</td></tr>
			<tr><td>&nbsp;&nbsp;</td></tr>
			<?php 

					$result = mysqli_query($conn, "CALL handymantools.getReservationTotals('" . $reservationID . "')");					
					while($row = $result->fetch_assoc()) {	
						echo "<tr>";
						echo "<td align='left'><b>Rental Price: </b>" . asDollars($row["totalRental"]) . "</td>";	
						echo "</tr>";							
						echo "<tr>";
						echo "<td align='left'><b>Deposit Held: </b>-" . asDollars($row["TotalDeposit"]) . "</td>";	
						echo "</tr>";				
						$total= $row["totalRental"] ;
					}
					$result->close();
					$conn->next_result();	
					echo "<tr>";
					echo "<td align='left'>---------------------</td>";	
					echo "</tr>";						
					echo "<tr>";
					echo "<td align='left'><b>Total :</b>" . asDollars($total) . "</td>";	
					echo "</tr>";												
			 ?>
		</table>
	 </div>
		
      <div class="row marketing">
      <footer class="footer">
        <p>&copy; Team 37, Inc.</p>
      </footer>

    <?PHP include 'about.php'; ?>   
    </div> <!-- /container -->
  </body>
</html>	