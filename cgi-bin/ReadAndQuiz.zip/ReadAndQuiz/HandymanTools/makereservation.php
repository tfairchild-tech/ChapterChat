<?php
	include 'requirecustomer.php';
?>
<?PHP include 'functions.php'; ?>
<!DOCTYPE html>
<html lang="en">
  <head>
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <!-- The above 3 meta tags *must* come first in the head; any other head content must come *after* these tags -->
    <meta name="description" content="">
    <meta name="author" content="">

    <title>Make Reservation</title>

    <script src="https://ajax.googleapis.com/ajax/libs/jquery/1.12.0/jquery.min.js"></script>
    <script src="./bootstrap/js/bootstrap.min.js"></script>
	<!-- JS for DatePicker -->
	<script src="./bootstrap/js/bootstrap-datepicker.min.js"></script>
    <!-- Bootstrap core CSS -->
    <link href="bootstrap/css/bootstrap.min.css" rel="stylesheet">
    <!-- Custom styles for this template -->
    <link href="bootstrap/css/jumbotron-narrow.css" rel="stylesheet">
	<!-- Styles for DatePicker -->
	<link rel="stylesheet" href="bootstrap/css/bootstrap-datepicker.css">    

  </head>
<script  type="text/javascript">
$(document).ready(function(){
	//Adds a datepicker to any input field with name ending in Date e.g. startDate, endDate.
	$("#startDate").datepicker({
		startDate: '0d',
		autoclose: true,
		format: 'yyyy-mm-dd'
	}).on('changeDate', function(e){
			var minDate = new Date(e.date.setTime( e.date.getTime() + 1 * 86400000 ));			
			$('#endDate').datepicker({format: 'yyyy-mm-dd', autoclose: true}).datepicker('setStartDate', minDate).focus();
	});	
});	
	function getAvailTools(){
		var startDate= $('#startDate').val();
		var endDate= $('#endDate').val();
		//document.write('getAvailTools.php?category='+category+'&startDate='+startDate+'&endDate='+endDate+'&r='+Math.random());
		if (startDate=='' || endDate==''){
			//alert('Please include both Starting Date and Ending Date.');
		}else{
			$.ajax({
				type: "POST",
				dataType: "text",
				url: 'getAvailTools.php?startDate='+startDate+'&endDate='+endDate+'&r='+Math.random(),
				success: function(myresponse){					
					$("#allAvailtools").html(myresponse);
				},
				error: function(){
					alert("An error has occurred, Please try again later.");		
				}
			});	
		}
	}
	function getAssocTools(toolNb){
		var  category = $('#category'+toolNb).val();
		var options="<option value='' rental='0' deposit='0'>Please choose one</option>";
		$("#allAvailtools > option").each(function(){	
			//alert($(this).attr('category').toLowerCase()+','+category.toLowerCase());
			if	($(this).attr('category').toLowerCase() ===  category.toLowerCase()   ){$(this).attr("disabled","");
				options= options +"<option value='"+$(this).val()+"' rental='"+$(this).attr('rental')+"' deposit='"+$(this).attr('deposit')+"'>"+$(this).html()+"</option>";
			}
		});			
		$("#tool"+toolNb).html(options);
	}
	
	function addTool(){
		var toolsCount = $('.toolClass').length;
		if (toolsCount<= 50){
			var newToolCount= toolsCount +1 ;
			var trhtml="<tr style='height:40px' class='toolClass' id='tooltr"+newToolCount+"'>";
			trhtml= trhtml +"<td align='left' colspan='2'><span>"+newToolCount+".</span>";
			trhtml= trhtml +"<select id='category"+newToolCount+"' name='category"+newToolCount+"' onchange='getAssocTools("+newToolCount+")' required >";
			trhtml= trhtml +"<option value=''>Please choose one</option>";
			trhtml= trhtml +"<option value='Power Tools'>Power Tools</option>";
			trhtml= trhtml +"<option value='Hand Tools'>Hand Tools</option>";
			trhtml= trhtml +"<option value='Construction'>Construction</option>";
			trhtml= trhtml +"</select></td>";
			trhtml= trhtml +"<td><select id='tool"+newToolCount+"' name='tool"+newToolCount+"' style='width:300px' required onchange='adjustSummary()'></select>";
			trhtml= trhtml +"</td></tr>";
			$('#toolTable > tbody > tr').eq(toolsCount+2).after(trhtml);
		}
	}
	
	function removeLastTool(){
		var toolsCount = $('.toolClass').length+2;
		if (toolsCount > 3)
			$('#toolTable tr:eq('+toolsCount+')').remove();
	}
	
	function isInArray(value, array) {
	  return array.indexOf(value) > -1;
	}
	function adjustSummary(){		
		// check for duplicate selection
		var i=1;
		var toolsCount = $('.toolClass').length;
		var duplicate=0; 
		var itemsArray=new Array();
		
		while (i <=toolsCount){	
			var toolId= $("#tool"+i).val();			
			if (isInArray(toolId, itemsArray)){	
				alert("Duplicate Tool!");
				$("#tool"+i).val('').attr("selected","selected");				
				i= toolsCount+1;
				duplicate=1;
			}else {
				itemsArray[i]= toolId;				
				i++;
			}
		}
		
		if (duplicate ==0){
			var numOfDays=daydiff( new Date($("#startDate").val()) , new Date($("#endDate").val()));
			if (numOfDays<= 0){
				alert("End Date is on or before Start Date, please fix!");
				$("#endDate").val('');
			}else{
				i=1;
				var items="";
				var totalDeposit=0; 
				var totalRental=0; 
				while (i <=toolsCount){			
					items= items + i+". " +$("#tool"+i+ " option:selected").text()+ "<br/>";		
					totalDeposit =totalDeposit +  (1*$("#tool"+i+ " option:selected").attr("deposit"));
					totalRental= totalRental + (numOfDays* $("#tool"+i+ " option:selected").attr("rental"));
					i++;
				}
				$("#selectedItems").val(items);
				$("#totalDeposit").val(totalDeposit);		
				$("#totalRental").val(totalRental);
				$("#numOfTools").val(toolsCount);
			}
		}
	}
	function daydiff(first, second) {
		return Math.round((second-first)/(1000*60*60*24));
	}

</script>
  <body>

    <div class="container">
      <div class="header clearfix">
        <nav>
          <ul class="nav nav-pills pull-right">
            <li role="presentation" class="active"><a href="custmainmenu.php">Home</a></li>
            <li role="presentation"><a href="#" data-toggle="modal" data-target="#myModal">About</a></li>
            <li role="presentation"><a href="logout.php">Logout</a></li>
          </ul>
        </nav>
        <h3 class="text-muted">Handyman Tools</h3>
      </div>

      <div class="jumbotron"> 
		<div class="container">
		  <div class="header clearfix">
			<h2>Make Reservation</h2>
		   </div>
		</div>	
		<div style='display:none'>
			<select id="allAvailtools" style='width:300px'></select>
		</div>
		<div>
			Please start by populating both Starting Date and Ending Date, then choose the Type Of Tool and a list of available tools will be shown in the Tool drop down.
		</div>
		<form method="post" action="ResSummary.php" >
		<table style='table-layout:fixed' id='toolTable'>                       
			<col width='200px' /><col width='50px' /><col width='320px' />
			<tbody>
			<tr style='height:40px'>
				<td align='right' colspan="2"><b>Starting Date:&nbsp;</b></td>
				<td align='left'><input  id='startDate' name='startDate' value="" onchange="getAvailTools()" placeholder="yyyy-mm-dd" required /></td>
			</tr>
			<tr style='height:40px'>
				<td align='right' colspan="2"><b>Ending Date:&nbsp;</b></td>
				<td align='left'><input id='endDate' name='endDate' value="" onchange="getAvailTools()"  placeholder="yyyy-mm-dd" required  /></td>
			</tr>
			<tr style='height:40px'>
				<td align='center' colspan="2"><b>Type Of Tool:  </b></td>
				<td align='center'><b>Tool:  </b></td>
			</tr>
			<tr style='height:40px' class='toolClass' id='tooltr1'>
				<td align='left' colspan="2"><span>1.</span>
					<select id="category1" name="category1" onchange="getAssocTools(1)" required>							
							<option value="dd">Please choose one</option>
							<option value="Power Tools">Power Tools</option>
							<option value="Hand Tools">Hand Tools</option>
							<option value="Construction">Construction</option>
					</select>
				</td>
				<td>
					<select id="tool1" name="tool1" style='width:300px' onchange="adjustSummary()" required>
					
					</select>
				</td>
			</tr>
			<tr style='height:80px'>
				<td align='center' colspan="2">
					<button type="button" class="btn  btn-xs btn-success" onclick='addTool()'>Add More Tools</button>
				</td>
				<td><button type="button" class="btn  btn-xs btn-success" onclick='removeLastTool()'>Remove Last Tool</button></td>
			</tr>
			<tr style='height:80px'>
				<td align='center' colspan="2">
					<input type="hidden" value="" size="50" id="selectedItems" name="selectedItems" />
					<input type="hidden" value="" id="totalRental" name="totalRental" />
					<input type="hidden" value="" id="numOfTools" name="numOfTools" />
					<input type="hidden" value="" id="totalDeposit" name="totalDeposit" />
					<button type='submit' class="btn  btn-xs btn-success">Calculate Total</button>
				</td>
			</tr>
			</tbody>
		</table>		
		</form>
	 </div>
		
      <div class="row marketing">
      <footer class="footer">
        <p>&copy; Team 37, Inc.</p>
      </footer>

    <?PHP include 'about.php'; ?>   
    </div> <!-- /container -->
  </body>
</html>