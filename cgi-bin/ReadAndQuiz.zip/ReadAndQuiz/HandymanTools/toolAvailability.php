<?php
	include 'requirecustomer.php';
	if (isset($_POST["startDate"])) {
		$startDate = $_POST["startDate"];
	}
	if (isset($_POST["endDate"])) {
		$endDate = $_POST["endDate"];
	}
	if (isset($_POST["category1"])) {
		$category = $_POST["category1"];
	}
	
?>
<!DOCTYPE html>
<html lang="en">
  <head>
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <!-- The above 3 meta tags *must* come first in the head; any other head content must come *after* these tags -->
    <meta name="description" content="">
    <meta name="author" content="">

    <title>Tool Availability</title>

    <script src="https://ajax.googleapis.com/ajax/libs/jquery/1.12.0/jquery.min.js"></script>
    <script src="./bootstrap/js/bootstrap.min.js"></script>
	<!-- JS for DatePicker -->
	<script src="./bootstrap/js/bootstrap-datepicker.min.js"></script>
    <!-- Bootstrap core CSS -->
    <link href="bootstrap/css/bootstrap.min.css" rel="stylesheet">
    <!-- Custom styles for this template -->
    <link href="bootstrap/css/jumbotron-narrow.css" rel="stylesheet">
	<!-- Styles for DatePicker -->
	<link rel="stylesheet" href="bootstrap/css/bootstrap-datepicker.css">    
	
  </head>
<script  type="text/javascript">
$(document).ready(function(){
	//get the tools
	getCategoryAvailTools();
	
});	
	function getCategoryAvailTools(){
		var startDate= "<?php echo $startDate; ?>";
		var endDate= "<?php echo $endDate; ?>";
	    var category= "<?php echo $category; ?>";
		$.ajax({
				type: "POST",
				dataType: "text",
				url: 'getCategoryAvailTools.php?startDate='+startDate+'&endDate='+endDate+'&category='+category+'&r='+Math.random(),
				success: function(myresponse){	
					$("#allAvailtools").html(myresponse);
				},
				error: function(){
					alert("An error has occurred, Please try again later.");		
				}
		});	
	}
</script>
  <body>

    <div class="container">
      <div class="header clearfix">
        <nav>
          <ul class="nav nav-pills pull-right">
            <li role="presentation" class="active"><a href="<?=$_SESSION['homepage']?>">Home</a></li>
            <li role="presentation"><a href="#" data-toggle="modal" data-target="#myModal">About</a></li>
            <li role="presentation"><a href="logout.php">Logout</a></li>
          </ul>
        </nav>
        <h3 class="text-muted">Handyman Tools</h3>
      </div>

      <div class="jumbotron"> 
		  <div class="container">
			<h2>Tool Availability</h2>
		  </div>
	  </div>		
		<div  id="allAvailtools">
		</div>
	 	
        <form method="post" action="ToolDetail.php" target= "_blank">
			<div class="form-group form-group-sm text-center">
                <label for="inputToolID">Tool ID#: </label>
                <input type="text" id="inputToolID" name="inputToolID" maxlength="4" size="4" required>
                <button class="btn btn-success btn-med" id="tidsubmit" name="tidsubmit" type="submit">View Tool Details</button>
			</div>
		</form>		
        <div class="form-group text-center">
            <br>
            <button type="button" class="btn btn-success btn-med" id="toolavail" name="toolavail" onclick="window.location='checkAvailability.php'">Back to Tool Availability</button>
            <br>
        </div>
  
      <footer class="footer">
        <p>&copy; Team 37, Inc.</p>
      </footer>

    <?PHP include 'about.php'; ?>   
    </div> <!-- /container -->
  </body>
</html>	