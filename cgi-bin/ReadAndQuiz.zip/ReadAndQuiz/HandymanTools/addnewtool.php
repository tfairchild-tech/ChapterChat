<?PHP include 'requireclerk.php'; ?>
<?php
    if(isset($_POST['submit']))
	{
		$clerk = $_SESSION["login"];
        $abbrDesc = $_POST["inputAbbrDesc"];
        $purchasePrice =  $_POST["inputPurchasePrice"];
        $rentalPrice = $_POST["inputRentalPrice"];
        $deposit = $_POST["inputDeposit"];
		$desc = $_POST["inputFullDesc"];
        $toolType = $_POST["selectToolType"];
        $acc = $_POST["inputAcc"];
        
        include 'db_connect.php';
        $sql ="CALL handymantools.insertTool(?,?,?,?,?,?,?,?)";
		
        $stmt = mysqli_prepare($conn, $sql);
				
        mysqli_stmt_bind_param($stmt,"sssdddss",$toolType,$desc,$abbrDesc,$rentalPrice,$deposit,$purchasePrice,$clerk,$acc);
        mysqli_stmt_execute($stmt);
        mysqli_stmt_close($stmt);
        
        mysqli_close($conn);
        
    }
?>
<!DOCTYPE html>
<html lang="en">
  <head>
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <!-- The above 3 meta tags *must* come first in the head; any other head content must come *after* these tags -->
    <meta name="description" content="">
    <meta name="author" content="">

    <title>Handyman Tools</title>

    <script src="https://ajax.googleapis.com/ajax/libs/jquery/1.12.0/jquery.min.js"></script>
    <script src="./bootstrap/js/bootstrap.min.js"></script>
    <!-- Bootstrap core CSS -->
    <link href="bootstrap/css/bootstrap.min.css" rel="stylesheet">

    <!-- Custom styles for this template -->
    <link href="bootstrap/css/jumbotron-narrow.css" rel="stylesheet">
    
    <!-- HTML5 shim and Respond.js for IE8 support of HTML5 elements and media queries -->
    <!--[if lt IE 9]>
      <script src="https://oss.maxcdn.com/html5shiv/3.7.2/html5shiv.min.js"></script>
      <script src="https://oss.maxcdn.com/respond/1.4.2/respond.min.js"></script>
    <![endif]-->
  </head>

  <body>

    <div class="container">
      <div class="header clearfix">
        <nav>
          <ul class="nav nav-pills pull-right">
            <li role="presentation" class="active"><a href="<?=$_SESSION['homepage']?>">Home</a></li>
            <li role="presentation"><a href="#" data-toggle="modal" data-target="#myModal">About</a></li>
            <li role="presentation"><a href="logout.php">Logout</a></li>
          </ul>
        </nav>
        <h3 class="text-muted">Handyman Tools</h3>
      </div>

      <div class="jumbotron">
        <p class="lead">
		<h2 class="form-group-heading">Add New Tool</h2>
            <form class="form-horizontal" method="post" action="<?php echo $_SERVER['PHP_SELF']; ?>">
                <div class="form-group">
                    <label for="inputAbbrDesc" class="col-sm-4 control-label">Abbreviated Description</label>
                    <div class="col-sm-8">
                    <input type="text" id="inputAbbrDesc" name="inputAbbrDesc" class="form-control" value= "" required autofocus>
                    </div>
                </div>
                <div class="form-group">
                    <label for="inputPurchasePrice" class="col-sm-4 control-label">Purchase Price $</label>
                    <div class="col-sm-8">
                    <input type="text" id="inputPurchasePrice" name="inputPurchasePrice" class="form-control"   required>
                    </div>
                </div>
                <div class="form-group">
                    <label for="inputRentalPrice" class="col-sm-4 control-label">Rental Price $ (per day)</label>
                    <div class="col-sm-8">
                    <input type="text" id="inputRentalPrice" name="inputRentalPrice" class="form-control" required>
                    </div>
                </div>
                <div class="form-group">
                    <label for="inputDeposit" class="col-sm-4 control-label">Deposit Amount $</label>
                    <div class="col-sm-8">
                    <input type="text" id="inputDeposit" name="inputDeposit" class="form-control"  required>
                    </div>
                </div>
                <div class="form-group">
                    <label for="inputFullDesc" class="col-sm-4 control-label">Full Description</label>
                    <div class="col-sm-8">
                    <textarea id ="inputFullDesc" name="inputFullDesc"class="form-control" required></textarea>
                    </div>
                </div>
				<div class="form-group">
                    <label for="selectToolType" class="col-sm-4 control-label">Tool Type</label>
                    <div class="col-sm-8">
                    <select id="selectToolType" class="form-control" name="selectToolType" onchange="changeToolType();">
						<option value="Hand Tools" selected="selected">Hand Tools</option>
						<option value="Construction">Construction</option>
						<option value="Power Tools">Power Tools</option>
					</select>
                    </div>
                </div>
				<div class="form-group" id="addAccDiv" style="display:none;">
                    <label for="inputAcc" class="col-sm-4 control-label">Add Accessories</label>
                    <div class="col-sm-8">
                    <input type="text" id="inputAcc" name="inputAcc" class="form-control">
                    </div>
                </div>
                <button class="btn btn-sm btn-primary" type="submit" name="submit">Submit</button>
            </form>
		</p>
      </div>

      <footer class="footer">
        <p>&copy; Team 37, Inc.</p>
      </footer>

      <?PHP include 'about.php'; ?>
    </div> <!-- /container -->

    <script src="./js/functions.js"></script>
	<script type="text/javascript">
		function changeToolType(){
			var element = document.getElementById("addAccDiv");
			if(document.getElementById("selectToolType").value == "Power Tools")
				element.style.display = 'inline';
			else element.style.display = 'none';		
		}
	</script>
  </body>
</html>
