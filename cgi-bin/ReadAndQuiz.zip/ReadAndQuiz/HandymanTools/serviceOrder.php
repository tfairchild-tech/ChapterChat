<?PHP //include 'requirecustomer.php'; ?>
<?PHP include 'functions.php'; ?>
<?PHP include 'requireclerk.php'; ?>
<?php
	$errmsg="";
	$somsg="";
    if(isset($_POST['submit']))
	{		
		$clerk = $_SESSION["login"];
        $toolID = $_POST["inputToolID"];
        $startDate =  $_POST["inputStartingDate"];
        $endDate = $_POST["inputEndingDate"];
        $repairCost = $_POST["inputRepairCost"];
		$toolAvail =0; 
		
		include('db_connect.php');
		
		$sql ="CALL handymantools.addServiceOrder(?,?,?,?,?)";
		
		$stmt = mysqli_prepare($conn, $sql);
				
		mysqli_stmt_bind_param($stmt,"issds",$toolID,$startDate,$endDate,$repairCost,$clerk);
		mysqli_stmt_execute($stmt) or die(mysql_error());
		$result = mysqli_stmt_get_result($stmt);
		mysqli_stmt_close($stmt);
		
		mysqli_close($conn);
		
		while($row = mysqli_fetch_array($result, MYSQLI_NUM))
		{
			foreach($row as $r)
			{
				$toolAvail = $r;
			}
		}
		
		if ($toolAvail == 0 ){
			$errmsg="This Tool is not available during that period of time";
		}else {
			$somsg="Service Order successfully created.";
		}
    }
?>

<!DOCTYPE html>
<html lang="en">
  <head>
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <!-- The above 3 meta tags *must* come first in the head; any other head content must come *after* these tags -->
    <meta name="description" content="">
    <meta name="author" content="">

    <title>Handyman Tools</title>

    <script src="https://ajax.googleapis.com/ajax/libs/jquery/1.12.0/jquery.min.js"></script>
    <script src="./bootstrap/js/bootstrap.min.js"></script>
    <!-- Bootstrap core CSS -->
    <link href="bootstrap/css/bootstrap.min.css" rel="stylesheet">

    <!-- Custom styles for this template -->
    <link href="bootstrap/css/jumbotron-narrow.css" rel="stylesheet">
	<!-- Styles for DatePicker -->
	<link rel="stylesheet" href="bootstrap/css/bootstrap-datepicker.css">
    
    <!-- HTML5 shim and Respond.js for IE8 support of HTML5 elements and media queries -->
    <!--[if lt IE 9]>
      <script src="https://oss.maxcdn.com/html5shiv/3.7.2/html5shiv.min.js"></script>
      <script src="https://oss.maxcdn.com/respond/1.4.2/respond.min.js"></script>
    <![endif]-->
  </head>

  <body>

    <div class="container">
      <div class="header clearfix">
        <nav>
          <ul class="nav nav-pills pull-right">
            <li role="presentation" class="active"><a href="<?=$_SESSION['homepage']?>">Home</a></li>
            <li role="presentation"><a href="#" data-toggle="modal" data-target="#myModal">About</a></li>
            <li role="presentation"><a href="logout.php">Logout</a></li>
          </ul>
        </nav>
        <h3 class="text-muted">Handyman Tools</h3>
      </div>

      <div class="jumbotron">
        <p class="lead">
		<h2 class="form-group-heading">Service Order</h2>
		<?php if ($errmsg<>''){ ?>
		<div class='alert alert-danger' role='alert'><?php echo $errmsg; ?></div>		
		<?php } ?>
		<?php if ($somsg<>''){ ?>
		<div class='alert alert-success' role='alert'><?php echo $somsg; ?></div>		
		<?php } ?>
            <form class="form-horizontal" method="post" action="<?php echo $_SERVER['PHP_SELF']; ?>">
                <div class="form-group">
                    <label for="inputToolID" class="col-sm-4 control-label">Tool ID</label>
                    <div class="col-sm-8">
                    <input type="text" id="inputToolID" name="inputToolID" class="form-control" value= "" required autofocus>
                    </div>
                </div>
                <div class="form-group">
                    <label for="inputStartingDate" class="col-sm-4 control-label">Starting Date</label>
                    <div class="col-sm-8">
                    <input type="text" id="inputStartingDate" name="inputStartingDate" class="form-control"   required>
                    </div>
                </div>
                <div class="form-group">
                    <label for="inputEndingDate" class="col-sm-4 control-label">Ending Date</label>
                    <div class="col-sm-8">
                    <input type="text" id="inputEndingDate" name="inputEndingDate" class="form-control" required>
                    </div>
                </div>
                <div class="form-group">
                    <label for="inputRepairCost" class="col-sm-4 control-label">Est. Cost of Repair $</label>
                    <div class="col-sm-8">
                    <input type="text" id="inputRepairCost" name="inputRepairCost" class="form-control"  required>
                    </div>
                </div>

                <button class="btn btn-sm btn-primary" type="submit" name="submit">Submit</button>
            </form>
		</p>
      </div>

      <footer class="footer">
        <p>&copy; Team 37, Inc.</p>
      </footer>

      <?PHP include 'about.php'; ?>
    </div> <!-- /container -->
	<script src="./bootstrap/js/bootstrap-datepicker.min.js"></script>
    <script src="./js/functions.js"></script>
	<script type="text/javascript">
		$("#inputStartingDate").datepicker({
			startDate: '0d',
			autoclose: true,
			format: 'yyyy-mm-dd'
		}).on('changeDate', function(e){
				var minDate = new Date(e.date.setTime( e.date.getTime() + 1 * 86400000 ));			
				$('#inputEndingDate').datepicker({format: 'yyyy-mm-dd', autoclose: true}).datepicker('setStartDate', minDate).focus();
		});			
	</script>
  </body>
</html>
