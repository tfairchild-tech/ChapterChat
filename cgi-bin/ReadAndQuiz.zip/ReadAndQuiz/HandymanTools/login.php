<?PHP include 'functions.php'; ?>
<?php
	// Start the session
	session_start();
    $badpassword = 0;
    if (isset($_POST["submit"])) {
		include('db_connect.php');
		$login = $_POST["inputEmail"];
		$pw = $_POST["inputPassword"];
        
		//clerk processing
		if ($_POST["logintype"] == "Clerk") {
			//stored proc
			$sql ="CALL handymantools.getClerkAuthentication(?,?)";
            $stmt = mysqli_prepare($conn, $sql);
            mysqli_stmt_bind_param($stmt,"ss",$login,$pw);
            mysqli_stmt_execute($stmt);
            $result = $stmt->get_result();
            
            while ($row = $result->fetch_array(MYSQLI_NUM)) {
                if ($row[0] == 1) {
				$_SESSION["logintype"] = 0;
				$_SESSION["login"] = $login;
                $_SESSION["homepage"] = "clerkmainmenu.php";
				}
            }
            /* free result set */
            mysqli_free_result($result);
            
            $stmt->close();
            
            //if successful login redirect to clerk menu
			if (isset($_SESSION["logintype"])) {
				header( 'Location: ./clerkmainmenu.php' ) ;
			}else
            {
                $badpassword = 1;  
            }
			
		} else {
		
			//customer processing	
			$sql ="CALL handymantools.getCustomerAuthentication(?,?)";
            $stmt = mysqli_prepare($conn, $sql);
            mysqli_stmt_bind_param($stmt,"ss",$login,$pw);
            mysqli_stmt_execute($stmt);
            $result = $stmt->get_result();
            
            if ($row = $result->fetch_assoc()) {
                if ($row["cnt"] == 1) {
                        $_SESSION["cnt"] = 1;
                    if($row["pw"]==$pw){
                        $_SESSION["logintype"] = 1;
                        $_SESSION["login"] = $login;
                        $_SESSION["homepage"] = "custmainmenu.php";
                        header( 'Location: ./custmainmenu.php' ) ;
                    }
                    else
                    {
                        $badpassword = 1; 
                    }
				}
            else
                {
                $_SESSION["inputEmail"] = $login; //this is set so we can prefill the new user form
                header( 'Location: ./newuser.php') ;        
                }
            }

    	}
	
		include 'db_close.php';
	}
	
?>

<!DOCTYPE html>
<html lang="en">
  <head>
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <!-- The above 3 meta tags *must* come first in the head; any other head content must come *after* these tags -->
    <meta name="description" content="">
    <meta name="author" content="">

    <title>Login</title>

    <script src="https://ajax.googleapis.com/ajax/libs/jquery/1.12.0/jquery.min.js"></script>
    <script src="./bootstrap/js/bootstrap.min.js"></script>
    <!-- Bootstrap core CSS -->
    <link href="bootstrap/css/bootstrap.min.css" rel="stylesheet">

    <!-- Custom styles for this template -->
    <link href="bootstrap/css/jumbotron-narrow.css" rel="stylesheet">
    <link href="bootstrap/css/signin.css" rel="stylesheet">
    
    <!-- HTML5 shim and Respond.js for IE8 support of HTML5 elements and media queries -->
    <!--[if lt IE 9]>
      <script src="https://oss.maxcdn.com/html5shiv/3.7.2/html5shiv.min.js"></script>
      <script src="https://oss.maxcdn.com/respond/1.4.2/respond.min.js"></script>
    <![endif]-->
  </head>

  <body>

    <div class="container">
      <div class="header clearfix">
        <nav>
          <ul class="nav nav-pills pull-right">
            <li role="presentation" class="active"><a href="#">Home</a></li>
            <li role="presentation"><a href="#" data-toggle="modal" data-target="#myModal">About</a></li>
            <li role="presentation"><a href="logout.php">Logout</a></li>
          </ul>
        </nav>
        <h3 class="text-muted">Handyman Tools</h3>
      </div>

      <div class="jumbotron">
        <p class="lead">
            <form class="form-signin" method="post" action="<?php echo $_SERVER['PHP_SELF']; ?>">
            <h2 class="form-signin-heading">Please sign in</h2>
            <label for="inputEmail" class="sr-only">Email address</label>
            <input type="text" id="inputEmail" name="inputEmail" class="form-control" placeholder="Login" required autofocus>
            <label for="inputPassword" class="sr-only">Password</label>
            <input type="password" id="inputPassword" name="inputPassword" class="form-control" placeholder="Password" required>
            <div data-toggle="buttons">
                <div class="btn-group">
						<label style="width:150px"class="btn btn-sm btn-primary radio-btn" for="rClerk">Clerk
						<input id="rClerk" name="logintype" type="radio" value="Clerk" required></label>
						<label style="width:150px" class="btn btn-sm btn-primary radio-btn" for="rCustomer">Customer
						<input id="rCustomer" name="logintype" type="radio" value="Customer" required></label>
					
                </div>
            </div>
			<br>
            <?php
			     if ($badpassword==1){
                 echo "<br><div class='alert alert-danger' role='alert'>Invalid Login or Password</div>";
				 }
			   ?>
            <div>   
                <button class="btn btn-sm btn-primary" id="submit" name="submit" type="submit">Sign in</button>
            </div>
            </form>
        </p>
      </div>

      <div class="row marketing">
      <footer class="footer">
        <p>&copy; Team 37, Inc.</p>
      </footer>

    <?PHP include 'about.php'; ?>  
    </div> <!-- /container -->
    
  </body>
</html>
