<?php
	include 'requirecustomer.php';
?>

<!DOCTYPE html>
<html lang="en">
  <head>
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <!-- The above 3 meta tags *must* come first in the head; any other head content must come *after* these tags -->
    <meta name="description" content="">
    <meta name="author" content="">

    <title>Check Tool Availability</title>

    <script src="https://ajax.googleapis.com/ajax/libs/jquery/1.12.0/jquery.min.js"></script>
    <script src="./bootstrap/js/bootstrap.min.js"></script>
	<!-- JS for DatePicker -->
	<script src="./bootstrap/js/bootstrap-datepicker.min.js"></script>
    <!-- Bootstrap core CSS -->
    <link href="bootstrap/css/bootstrap.min.css" rel="stylesheet">
    <!-- Custom styles for this template -->
    <link href="bootstrap/css/jumbotron-narrow.css" rel="stylesheet">
	<!-- Styles for DatePicker -->
	<link rel="stylesheet" href="bootstrap/css/bootstrap-datepicker.css">    

  </head>
<script  type="text/javascript">
$(document).ready(function(){
	//Adds a datepicker to any input field with name ending in Date e.g. startDate, endDate.
	$("#startDate").datepicker({
		startDate: '0d',
		autoclose: true,
		format: 'yyyy-mm-dd'
	}).on('changeDate', function(e){
			$('#endDate').datepicker({format: 'yyyy-mm-dd', autoclose: true}).datepicker('setStartDate', e.date).focus();
	});	
});	
	
</script>
  <body>

    <div class="container">
      <div class="header clearfix">
        <nav>
          <ul class="nav nav-pills pull-right">
            <li role="presentation" class="active"><a href="custmainmenu.php">Home</a></li>
            <li role="presentation"><a href="#" data-toggle="modal" data-target="#myModal">About</a></li>
            <li role="presentation"><a href="logout.php">Logout</a></li>
          </ul>
        </nav>
        <h3 class="text-muted">Handyman Tools</h3>
      </div>

      <div class="jumbotron"> 
		<div class="container">
			<h2>Check Tool Availability</h2>
		</div>	
	  </div>
		<div style='display:none'>
			<select id="allAvailtools" style='width:300px'></select>
		</div>
		
		<form method="post" action="toolAvailability.php" >
		<table style='table-layout:fixed' id='toolTable'>                       
			<col width='200px' /><col width='50px' /><col width='320px' />
			<tbody>
			<tr style='height:40px'>
				<td align='right' colspan="2"><b>Tool Category:&nbsp;</b></td>
				<td align='left' colspan="2" style='height:40px' class='toolClass' id='tooltr1'>
					<select id="category1" name="category1" onchange="getAssocTools(1)" required>							
							<option value="">Please choose Type Of Tool</option>
							<option value="Power Tools">Power Tools</option>
							<option value="Hand Tools">Hand Tools</option>
							<option value="Construction">Construction</option>
					</select>
				</td>
			</tr>
			<tr style='height:40px'>
				<td align='right' colspan="2"><b>Starting Date:&nbsp;</b></td>
				<td align='left'><input  id='startDate' name='startDate' value="" placeholder="yyyy-mm-dd" required /></td>
			</tr>
			<tr style='height:40px'>
				<td align='right' colspan="2"><b>Ending Date:&nbsp;</b></td>
				<td align='left'><input id='endDate' name='endDate' value="" placeholder="yyyy-mm-dd" required /></td>
			</tr>
			</tbody>
		</table>
		<div class="container text-center">
                <button class="btn btn-med btn-success" id="submit" name="submit" type="submit">Submit</button>
        <div>		
		</form>
		
      <div class="row marketing">
      <footer class="footer">
        <p>&copy; Team 37, Inc.</p>
      </footer>

    <?PHP include 'about.php'; ?>   
    </div> <!-- /container -->
  </body>
</html>