<?PHP include 'functions.php'; ?>
<?php
	include 'requirecustomer.php';	
	$name = '';
	$homephone = '';
	$workphone= '';
	$address= '';
	$email= $_SESSION["login"];
	
    if ($email <> '') {		
		include('db_connect.php');
		//call getCustomerInfo stored proc to get a customer information
		$result = mysqli_query($conn, "CALL handymantools.getCustomerInfo('" . $email . "')");
		while($row = $result->fetch_assoc()) {			
			$name = $row["FirstName"] . " " . $row["LastName"] ;
			$homephone = $row["HomePhone"];
			$workphone= $row["WorkPhone"];
			$address= $row["Address"];
			
		}
		$result->close();
		$conn->next_result();
		//call getCustomerReservationHistory stored proc to get a customer reservation history
		$qResHistory = mysqli_query($conn, "CALL handymantools.getCustomerReservationHistory('" . $email . "')") or die("Query fail: " . mysqli_error($conn));
	}
	else{
		header( 'Location: ./login.php' ) ;
	}
?>

<!DOCTYPE html>
<html lang="en">
  <head>
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <!-- The above 3 meta tags *must* come first in the head; any other head content must come *after* these tags -->
    <meta name="description" content="">
    <meta name="author" content="">

    <title>Profile</title>

    <script src="https://ajax.googleapis.com/ajax/libs/jquery/1.12.0/jquery.min.js"></script>
    <script src="./bootstrap/js/bootstrap.min.js"></script>
    <!-- Bootstrap core CSS -->
    <link href="bootstrap/css/bootstrap.min.css" rel="stylesheet">

    <!-- Custom styles for this template -->
    <link href="bootstrap/css/jumbotron-narrow.css" rel="stylesheet">
    <link href="bootstrap/css/signin.css" rel="stylesheet">
    
    <!-- HTML5 shim and Respond.js for IE8 support of HTML5 elements and media queries -->
    <!--[if lt IE 9]>
      <script src="https://oss.maxcdn.com/html5shiv/3.7.2/html5shiv.min.js"></script>
      <script src="https://oss.maxcdn.com/respond/1.4.2/respond.min.js"></script>
    <![endif]-->
  </head>

  <body>

    <div class="container">
      <div class="header clearfix">
        <nav>
          <ul class="nav nav-pills pull-right">
            <li role="presentation" class="active"><a href="custmainmenu.php">Home</a></li>
            <li role="presentation"><a href="#" data-toggle="modal" data-target="#myModal">About</a></li>
            <li role="presentation"><a href="logout.php">Logout</a></li>
          </ul>
        </nav>
        <h3 class="text-muted">Handyman Tools</h3>
      </div>

      <div class="jumbotron" style="width:800px"> 
		<div class="container">
			<h2>Profile</h2>
		</div>	
	
		<table>                       
			<tr style='height:30px'><td align='left'><b>Email Address:</b> <?php echo $email  ?></td></tr>
			<tr style='height:30px'><td align='left'><b>Name:</b> <?php echo $name;  ?></td></tr>
			<tr style='height:30px'><td align='left'><b>Work Phone:</b> <?php echo $workphone;  ?></td></tr>
			<tr style='height:30px'><td align='left'><b>Home Phone:</b> <?php echo $homephone;  ?></td></tr>			
			<tr style='height:30px'><td align='left'><b>Address:</b> <?php echo $address;  ?></td></tr>						
		</table>	
	</div>
		<div class="container">
			<h4>Reservation History</h4>			
		</div>
		<table class="table table-striped table-bordered table-hover" style="table-layout:fixed">
			<col width='60px' /><col width='200px' />
			<col width='100px' /><col width='100px' />
			<col width='80px' /><col width='80px' />
			<col width='100px' /><col width='100px' />
			<thead>
				<tr>
					<th>Res #</th>
					<th>Tools</th>
					<th>Start</th>
					<th>End</th>
					<th>Rental Price</th>
					<th>Deposit</th>
					<th>Pick-Up Clerk</th>
					<th>Drop-Off Clerk</th>
				</tr>
			</thead>
			<tbody>
			<?php
			while($row = $qResHistory->fetch_assoc()) {		
				echo "<tr>";
					echo "<th>". $row["ReservationID"] ."</th>";
					echo "<td style='width:200px'>". $row["tools"] ."</td>";
					echo "<td>". $row["StartDate"] ."</td>";
					echo "<td>". $row["EndDate"] ."</td>";					
					echo "<td>". asDollars($row["DailyRentalPrice"]) ."</td>";
					echo "<td>". asDollars($row["DepositAmount"]) ."</td>";
					echo "<td>". $row["PickUpClerk"] ."</td>";
					echo "<td>". $row["DropOffClerk"] ."</td>";					
				echo "</tr>";
			}
			?>						
			</tbody>
		</table>

  
	   <div class="container text-center">
				<br>
                <button  type="button"  class="btn btn-success btn-med" onclick="window.location='custmainmenu.php'">Home</button>
      <div>		
      <div class="row marketing">
      <footer class="footer">
        <p>&copy; Team 37, Inc.</p>
      </footer>

    <?PHP include 'about.php'; ?>  
    
    </div> <!-- /container -->

  </body>
</html>
<?php $conn->close(); ?>
