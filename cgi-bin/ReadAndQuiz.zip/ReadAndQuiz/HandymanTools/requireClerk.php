<?PHP
/*
session_start();
if (isset($_SESSION['logintype'])){
    if ($_SESSION['logintype'] != 0)
    {
        header( 'Location: ./logout.php' ) ;
    } 
}
else
{
    header( 'Location: ./login.php' ) ;
}*/
?>