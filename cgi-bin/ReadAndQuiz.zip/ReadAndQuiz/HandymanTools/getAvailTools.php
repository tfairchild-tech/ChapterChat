<?PHP include 'functions.php'; ?>
<?php
	
	$sql=" SELECT t.toolID, t.abbrDescription, t.dailyRentalPrice, t.Category, t.DepositAmount FROM Handymantools.tool t";
	$sql= $sql . " WHERE t.toolID not in (";
	$sql= $sql . " SELECT toolid FROM Handymantools.unavailableToolsByDate";
	$sql= $sql . " WHERE startdate <= '". $_GET["endDate"] ."' and enddate >= '". $_GET["startDate"] ."'";
	$sql= $sql . " )";
	//echo $sql;
	$tools="<option value='' category='' deposit='0' rental='0' >Please choose a Tool</option>";
	include('db_connect.php');	
	$result = mysqli_query($conn, $sql);
	while($row = $result->fetch_assoc()) {
			$tools= $tools . "<option value='".$row["toolID"]."'  category='".$row["Category"]."' rental='".$row["dailyRentalPrice"]."' deposit='".$row["DepositAmount"]."'>[".$row["toolID"]."] ".$row["abbrDescription"]." $".$row["dailyRentalPrice"]."</option>";			
	}	
	// Free result set
	mysqli_free_result($result);	

	echo $tools;
?>