# CS6400Spring16Team37
# Create statements for the HandyManTools database tables and views

--
-- Table structure for table `accessory`
--
CREATE TABLE `accessory` (
  `ToolID` int(11) NOT NULL,
  `AccessoryList` varchar(250) DEFAULT NULL,
  PRIMARY KEY (`ToolID`),
  CONSTRAINT `ToolIDacc` FOREIGN KEY (`ToolID`) REFERENCES `tool` (`ToolID`) ON DELETE NO ACTION ON UPDATE NO ACTION
) 

--
-- Table structure for table `clerk`
--


CREATE TABLE `clerk` (
  `Login` varchar(50) NOT NULL,
  `Password` varchar(50) NOT NULL,
  `FirstName` varchar(50) DEFAULT NULL,
  `LastName` varchar(50) DEFAULT NULL,
  PRIMARY KEY (`Login`)
) 

--
-- Table structure for table `customer`
--


CREATE TABLE `customer` (
  `Login` varchar(50) NOT NULL,
  `Password` varchar(50) NOT NULL,
  `FirstName` varchar(50) DEFAULT NULL,
  `LastName` varchar(50) DEFAULT NULL,
  `WorkPhone` varchar(45) DEFAULT NULL,
  `HomePhone` varchar(45) DEFAULT NULL,
  `Address` varchar(256) DEFAULT NULL,
  PRIMARY KEY (`Login`)
)

--
-- Table structure for table `reservation`
--

CREATE TABLE `reservation` (
  `ReservationID` int(11) NOT NULL AUTO_INCREMENT,
  `CustomerLogin` varchar(50) DEFAULT NULL,
  `StartDate` date DEFAULT NULL,
  `EndDate` date DEFAULT NULL,
  `CC` varchar(16) DEFAULT NULL,
  `CCExpiration` varchar(4) DEFAULT NULL,
  `DropOffClerkLogin` varchar(50) DEFAULT NULL,
  `DropOffDate` date DEFAULT NULL,
  `PickUpClerkLogin` varchar(50) DEFAULT NULL,
  `PickUpDate` date DEFAULT NULL,
  PRIMARY KEY (`ReservationID`),
  KEY `CustomerLogin_idx` (`CustomerLogin`),
  KEY `PickUpClerkLogin_idx` (`PickUpClerkLogin`),
  KEY `DropOffClerkLogin_idx` (`DropOffClerkLogin`),
  CONSTRAINT `CustomerLogin` FOREIGN KEY (`CustomerLogin`) REFERENCES `customer` (`Login`) ON DELETE NO ACTION ON UPDATE NO ACTION,
  CONSTRAINT `DropOffClerkLogin` FOREIGN KEY (`DropOffClerkLogin`) REFERENCES `clerk` (`Login`) ON DELETE NO ACTION ON UPDATE NO ACTION,
  CONSTRAINT `PickUpClerkLogin` FOREIGN KEY (`PickUpClerkLogin`) REFERENCES `clerk` (`Login`) ON DELETE NO ACTION ON UPDATE NO ACTION
) 

--
-- Table structure for table `reservedtool`
--


CREATE TABLE `reservedtool` (
  `ReservationID` int(11) NOT NULL,
  `ToolID` int(11) NOT NULL,
  PRIMARY KEY (`ReservationID`,`ToolID`),
  KEY `ToolID_idx` (`ToolID`),
  CONSTRAINT `ReservationID` FOREIGN KEY (`ReservationID`) REFERENCES `reservation` (`ReservationID`) ON DELETE NO ACTION ON UPDATE NO ACTION,
  CONSTRAINT `ToolID` FOREIGN KEY (`ToolID`) REFERENCES `tool` (`ToolID`) ON DELETE NO ACTION ON UPDATE NO ACTION
) 

--
-- Table structure for table `serviceorder`
--

CREATE TABLE `serviceorder` (
  `ToolID` int(11) NOT NULL,
  `StartDate` date NOT NULL,
  `EndDate` date DEFAULT NULL,
  `Cost` decimal(10,2) DEFAULT NULL,
  `ClerkLogin` varchar(50) DEFAULT NULL,
  PRIMARY KEY (`ToolID`,`StartDate`),
  KEY `ClerkLogin_idx` (`ClerkLogin`),
  CONSTRAINT `ClerkLogin` FOREIGN KEY (`ClerkLogin`) REFERENCES `clerk` (`Login`) ON DELETE NO ACTION ON UPDATE NO ACTION
) 

--
-- Table structure for table `tool`
--


CREATE TABLE `tool` (
  `ToolID` int(11) NOT NULL AUTO_INCREMENT,
  `Category` varchar(45) DEFAULT NULL,
  `Description` varchar(256) DEFAULT NULL,
  `AbbrDescription` varchar(50) DEFAULT NULL,
  `DailyRentalPrice` decimal(10,2) DEFAULT NULL,
  `DepositAmount` decimal(10,2) DEFAULT NULL,
  `Status` varchar(50) DEFAULT NULL,
  `OrigPurchasePrice` decimal(10,2) DEFAULT NULL,
  `SellingClerkLogin` varchar(50) DEFAULT NULL,
  `SoldDate` date DEFAULT NULL,
  `CreatedClerkLogin` varchar(50) DEFAULT NULL,
  PRIMARY KEY (`ToolID`),
  KEY `SellingClerkLogin_idx` (`SellingClerkLogin`),
  KEY `CreatedClerkLogin_idx` (`CreatedClerkLogin`),
  CONSTRAINT `CreatedClerkLogin` FOREIGN KEY (`CreatedClerkLogin`) REFERENCES `clerk` (`Login`) ON DELETE NO ACTION ON UPDATE NO ACTION,
  CONSTRAINT `SellingClerkLogin` FOREIGN KEY (`SellingClerkLogin`) REFERENCES `clerk` (`Login`) ON DELETE NO ACTION ON UPDATE NO ACTION
) 


-------------------------------------- VIEW DEFINITIONS BELOW THIS LINE ------------------------------------------------

--
-- Final view structure for view `rptclerkpickupdropoffs`
--

 CREATE VIEW `rptclerkpickupdropoffs` AS 
 SELECT `c`.`LastName` AS `LastName`,
        `c`.`FirstName` AS `FirstName`,
         count(`pu`.`ReservationID`) AS `PickUps`,
         count(`dr`.`ReservationID`) AS `DropOffs` 
 FROM (
      (`clerk` `c` 
        LEFT JOIN `reservation` `pu` on (((`c`.`Login` = `pu`.`PickUpClerkLogin`) and (month(now()) = month(`pu`.`PickUpDate`)) and (year(now()) = year(`pu`.`PickUpDate`))))) 
        LEFT JOIN `reservation` `dr` on (((`c`.`Login` = `dr`.`DropOffClerkLogin`) and (month(now()) = month(`dr`.`DropOffDate`)) and (year(now()) = year(`dr`.`DropOffDate`))))) 
        GROUP BY `c`.`LastName`,`c`.`FirstName` 
        ORDER BY (count(`pu`.`ReservationID`) + count(`dr`.`ReservationID`)) desc;


--
-- Final view structure for view `rptlastmonthrentals`
--

CREATE VIEW `rptlastmonthrentals` 
AS 
SELECT `c`.`LastName` AS `LastName`,
       `c`.`FirstName` AS `FirstName`,
       `c`.`Login` AS `Login`,
       sum((`r`.`EndDate` - `r`.`StartDate`)) AS `sum(r.enddate-r.startdate)` 
  FROM (`customer` `c` 
         JOIN `reservation` `r` on((`c`.`Login` = `r`.`CustomerLogin`))
        ) 
  WHERE (`r`.`EndDate` between (now() - interval 1 month) and now()) 
  GROUP BY `c`.`LastName`,`c`.`FirstName`,`c`.`Login`;


--
-- Final view structure for view `rpttotalprofit`
--

CREATE VIEW `rpttotalprofit` AS 
SELECT `t`.`ToolID` AS `ToolID`,
       `t`.`AbbrDescription` AS `AbbrDescription`,
       (sum(`t`.`DailyRentalPrice`) * (`r`.`EndDate` - `r`.`StartDate`)) AS `rentalprofit`,
       sum((`t`.`OrigPurchasePrice` + isnull(`so`.`totalcost`))) AS `costoftool` 
  FROM (((`tool` `t` 
           LEFT JOIN `reservedtool` `rt` on((`t`.`ToolID` = `rt`.`ToolID`))) 
           LEFT JOIN `reservation` `r` on((`rt`.`ReservationID` = `r`.`ReservationID`))) 
           LEFT JOIN `toolserviceorderstotals` `so` on((`t`.`ToolID` = `so`.`toolid`)))
  WHERE ((`t`.`Status` <> 'SOLD') and (`r`.`DropOffDate` is not null)) 
  GROUP BY `t`.`ToolID`,`t`.`AbbrDescription` ;

--
-- Final view structure for view `toolserviceorderstotals`
--

CREATE VIEW `toolserviceorderstotals` AS 
SELECT `t`.`ToolID` AS `toolid`,
        sum(`s`.`Cost`) AS `totalcost` 
  FROM (`tool` `t` 
         JOIN `serviceorder` `s` on((`t`.`ToolID` = `s`.`ToolID`)))
GROUP BY `t`.`ToolID`;

--
-- Final view structure for view `unavailabletoolsbydate`
--

CREATE VIEW `unavailabletoolsbydate` AS 
    SELECT `t`.`ToolID` AS `toolid`,
           `r`.`StartDate` AS `startdate`,
          `r`.`EndDate` AS `enddate`,
          'reserved' AS `status` 
    FROM ((`tool` `t` 
            LEFT JOIN `reservedtool` `rt` on((`t`.`ToolID` = `rt`.`ToolID`))) 
            LEFT JOIN `reservation` `r` on((`rt`.`ReservationID` = `r`.`ReservationID`))
         ) 
    WHERE (`r`.`StartDate` is not null) 
UNION 
    SELECT `t`.`ToolID` AS `toolid`,
           `s`.`StartDate` AS `startdate`,
           `s`.`EndDate` AS `enddate`,
           'out for service' AS `status` 
      FROM (`tool` `t` 
            LEFT JOIN `serviceorder` `s` on((`t`.`ToolID` = `s`.`ToolID`))
           ) 
     WHERE (`s`.`StartDate` is not null) 
UNION 
    SELECT `tool`.`ToolID` AS `ToolID`,
            `tool`.`SoldDate` AS `solddate`,
            '9999-12-31' AS `9999-12-31`,
            'sold' AS `sold` from `tool`
    WHERE (`tool`.`Status` = 'SOLD') 
    ORDER BY `toolid`,`startdate`;
