<?PHP include 'requireclerk.php'; ?>
<?PHP include 'functions.php'; ?>
<?php
    if(isset($_POST['submit']))
	{
		$clerk = $_SESSION["login"];
        $reservationID = $_POST["reservationID"];	   
        include 'db_connect.php';
		$dropOffValid=0;
		if  ($clerk<>''){
			$resultRes = mysqli_query($conn, "CALL handymantools.getReservationInfo('" . $reservationID . "')");				
		}else{
			header( 'Location: ./login.php' ) ;
		
		}
    }

?>

<!DOCTYPE html>
<html lang="en">
  <head>
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <!-- The above 3 meta tags *must* come first in the head; any other head content must come *after* these tags -->
    <meta name="description" content="">
    <meta name="author" content="">

    <title>Drop-Off</title>

    <script src="https://ajax.googleapis.com/ajax/libs/jquery/1.12.0/jquery.min.js"></script>
    <script src="./bootstrap/js/bootstrap.min.js"></script>
    <!-- Bootstrap core CSS -->
    <link href="bootstrap/css/bootstrap.min.css" rel="stylesheet">
    <!-- Custom styles for this template -->
    <link href="bootstrap/css/jumbotron-narrow.css" rel="stylesheet">
    <link href="bootstrap/css/signin.css" rel="stylesheet">
  </head>
  <body>

    <div class="container">
		<div class="header clearfix">
			<nav>
			  <ul class="nav nav-pills pull-right">
				<li role="presentation" class="active"><a href="<?=$_SESSION['homepage']?>">Home</a></li>
				<li role="presentation"><a href="#" data-toggle="modal" data-target="#myModal">About</a></li>
				<li role="presentation"><a href="logout.php">Logout</a></li>
			  </ul>
			</nav>
			<h3 class="text-muted">Handyman Tools</h3>
		</div>
		<div class="jumbotron">
			<p class="lead">
			<h2 class="form-group-heading">Drop-Off</h2>			
                    <form class="form-horizontal" method="post" action="<?php echo $_SERVER['PHP_SELF']; ?>">
                        <table style='table-layout:fixed' id='toolTable'>                       
                        <col width='180px' /><col width='150px' /><col width='300px' />
                            <tr>
                                <td><label for="reservationID" class="control-label">Reservation Number</label></td>
                                <td><input type="text" id="reservationID" name="reservationID" size="10" class="form-control" value= "" required autofocus />
                                </td>
                                <td><button class="btn btn-xs btn-primary" type="submit" name="submit">Lookup Reservation</button></td>
                            </tr>
                        </table>
                    </form>
				<?php if(isset($_POST['submit'])){  
						if ($clerk<>''){
							if (mysqli_num_rows($resultRes) == 0 ){
								echo "<div class='alert alert-danger' role='alert'>Reservation number ". $reservationID." is not found.</div>";
							}
							else{
								
				?>
				<table>                       
					<tr style='height:30px'><td align='left'><b>Reservation Number:</b> <?php echo $reservationID  ?></td></tr>
					<?php						
						$i=1;
						while($row = $resultRes->fetch_assoc()) {	
							if ($row["PickupClerkName"] == '') {
								echo "<tr>";
								echo "<td align='left'><div class='alert alert-warning' role='alert'>This reservation has not been picked up yet.</div></td>";							
								echo "</tr>";	
					 	    }
							if ($row["dropOffClerkName"] <> '') {
								echo "<tr>";
								echo "<td align='left'><div class='alert alert-success' role='alert'>This reservation was dropped off on ". $row["DropOffDate"] ." by the ".$row["dropOffClerkName"].".</div></td>";								
								echo "</tr>";														
							}
							if ($row["PickupClerkName"] <> '' && $row["dropOffClerkName"] == '')
								{$dropOffValid= 1;
								echo "<div class='alert alert-success' role='alert'>This reservation is available for dropoff.</div>";
								
								}
							$i++;							
							
						}								
						$resultRes->close();
						$conn->next_result();	

					?>		
					<tr style='height:30px'><td align='left'><b>Tools Required:</b></td></tr>
					<?php			
						$result = mysqli_query($conn, "CALL handymantools.getReservationTools('" . $reservationID . "')");
							$i=1;
							while($row = $result->fetch_assoc()) {	
								echo "<tr>";
								echo "<td align='left'><b>" . $i . ".</b>&nbsp;&nbsp;[ID: " . $row["ToolID"] . "]" . "  " . $row["AbbrDescription"] . "</td>";							
								echo "</tr>";
								$i++;
							}								
						$result->close();
						$conn->next_result();
					?>
				<tr><td>&nbsp;&nbsp;</td></tr>
				<tr><td>&nbsp;&nbsp;</td></tr>
				<?php 

						$result = mysqli_query($conn, "CALL handymantools.getReservationTotals('" . $reservationID . "')");					
						while($row = $result->fetch_assoc()) {	
							echo "<tr>";
							echo "<td align='left'><b>Deposit Required </b>" . asDollars($row["TotalDeposit"]) . "</td>";	
							echo "</tr>";
							echo "<tr>";
							echo "<td align='left'><b>Estimated Cost </b>" . asDollars($row["totalRental"]) . "</td>";	
							echo "</tr>";							
						}
						$result->close();
						$conn->next_result();							
																	
				 ?>
				</table>
				<?php  }
					} 
				  }
				?>	
				<hr/>
				<form class="form-horizontal" method="post" action="rentalReceipt.php">					
					<input type="hidden"  id="reservationID"  name="reservationID" value="<?php echo $reservationID  ?>" />
					<button class="btn btn-xs btn-primary" type="submit" name="createReceipt" <?php if ($reservationID=="" || $dropOffValid==0){ echo "disabled"; }  ?>>Create Receipt</button
				</form>					
			</p>
		</div>		
      <div class="row marketing">
      <footer class="footer">
        <p>&copy; Team 37, Inc.</p>
      </footer>

    <?PHP include 'about.php'; ?>  
    </div> <!-- /container -->

  </body>
</html>
<?php if(isset($_POST['submit'])){ $conn->close();} ?>
