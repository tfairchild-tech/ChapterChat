<?PHP include 'functions.php'; ?>
<?php
	// Start the session
	session_start();

    if(isset($_POST['submit']))
	{
        $email = $_POST["inputEmail"];
        $password =  $_POST["inputPassword"];
        $firstname = $_POST["firstName"];
        $lastname = $_POST["lastName"];
        $homephone = $_POST["homePhoneArea"] . $_POST["homePhone"];
        $workphone = $_POST["workPhoneArea"] . $_POST["workPhone"];
        $address = $_POST["address"];
        
        include 'db_connect.php';
        $sql ="CALL handymantools.insertCustomer(?,?,?,?,?,?,?)";
        $stmt = mysqli_prepare($conn, $sql);
        mysqli_stmt_bind_param($stmt,"sssssss",$email,$password,$firstname,$lastname,$workphone,$homephone,$address);
        mysqli_stmt_execute($stmt);
        mysqli_stmt_close($stmt);
        
        mysqli_close($conn);
        
        session_start();
        $_SESSION["logintype"] = 1;
        $_SESSION["login"] = $email;
        header( 'Location: custmainmenu.php' ) ;
    }
    else{
	
	if(isset($_SESSION['inputEmail'])) {
		$tmpemail = $_SESSION['inputEmail'];
	} else { 
		$tmpemail = '';
	}
?>
<!DOCTYPE html>
<html lang="en">
  <head>
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <!-- The above 3 meta tags *must* come first in the head; any other head content must come *after* these tags -->
    <meta name="description" content="">
    <meta name="author" content="">

    <title>New User</title>

    <script src="https://ajax.googleapis.com/ajax/libs/jquery/1.12.0/jquery.min.js"></script>
    <script src="./bootstrap/js/bootstrap.min.js"></script>
    <!-- Bootstrap core CSS -->
    <link href="bootstrap/css/bootstrap.min.css" rel="stylesheet">

    <!-- Custom styles for this template -->
    <link href="bootstrap/css/jumbotron-narrow.css" rel="stylesheet">
    
    <!-- HTML5 shim and Respond.js for IE8 support of HTML5 elements and media queries -->
    <!--[if lt IE 9]>
      <script src="https://oss.maxcdn.com/html5shiv/3.7.2/html5shiv.min.js"></script>
      <script src="https://oss.maxcdn.com/respond/1.4.2/respond.min.js"></script>
    <![endif]-->
  </head>

  <body>

    <div class="container">
      <div class="header clearfix">
        <nav>
          <ul class="nav nav-pills pull-right">
            <li role="presentation" class="active"><a href="login.php">Home</a></li>
            <li role="presentation"><a href="#" data-toggle="modal" data-target="#myModal">About</a></li>
            <li role="presentation"><a href="logout.php">Logout</a></li>
          </ul>
        </nav>
        <h3 class="text-muted">Handyman Tools</h3>
      </div>

      <div class="jumbotron">
        <p class="lead">
            <h2 class="form-group-heading">Create a Profile</h2>
            <h3>Handyman Tools rental requires a valid profile for every user before they can make reservations.</h3>
            <form name="newuser" class="form-horizontal" method="post" action="<?php echo $_SERVER['PHP_SELF']; ?>">
                <div class="form-group">
                    <label for="inputEmail" class="col-sm-3 control-label">Email Address</label>
                    <div class="col-sm-9">
                    <input type="email" id="inputEmail" name="inputEmail" class="form-control" value= "<?php echo (isset($tmpemail))?$tmpemail:'';?>" required autofocus>
                    </div>
                </div>
                <div class="form-group">
                    <label for="inputPassword" class="col-sm-3 control-label">Password</label>
                    <div class="col-sm-9">
                    <input type="password" id="inputPassword" name="inputPassword" class="form-control"  required>
                    <input type="password" id="confirmPassword" name="confirmPassword" class="form-control" placeholder="Confirm Password" required>
                    </div>
                </div>
                <div class="form-group">
                    <label for="firstName" class="col-sm-3 control-label">First Name</label>
                    <div class="col-sm-9">
                    <input type="text" id="firstName" name="firstName" class="form-control" required>
                    </div>
                </div>
                <div class="form-group">
                    <label for="lastName" class="col-sm-3 control-label">Last Name</label>
                    <div class="col-sm-9">
                    <input type="text" id="lastName" name="lastName" class="form-control" required>
                    </div>
                </div>
                <div class="form-group form-inline">
                    <label for="homePhoneArea" class="col-sm-3 control-label">Home Phone</label>
                    <div class="col-sm-6">
                    <input type="text" id="homePhoneArea" name="homePhoneArea" class="form-control" placeholder="Area" required style="width:60px">
                    <input type="text" id="homePhone" name="homePhone" class="form-control" placeholder="Phone" required>
                    </div>
                </div>
                <div class="form-group form-inline">
                    <label for="workPhoneArea" class="col-sm-3 control-label">Work Phone</label>
                    <div class="col-sm-6">
                    <input type="text" id="workPhoneArea" name="workPhoneArea" class="form-control" placeholder="Area" required style="width:60px">
                    <input type="text" id="workPhone" name="workPhone" class="form-control" placeholder="Phone" required>
                    </div>
                </div>
                <div class="form-group">
                    <label for="address" class="col-sm-3 control-label">Address</label>
                    <div class="col-sm-9">
                        <textarea id="address" name="address" class="form-control" rows="3" required></textarea>
                    </div>
                </div>
                <button class="btn btn-sm btn-success" type="submit" name="submit" id="submit">Submit</button>
            </form>
        </p>
      </div>
    
      <footer class="footer">
        <p>&copy; Team 37, Inc.</p>
      </footer>
    
    <?PHP include 'about.php'; ?>
    </div> <!-- /container -->
    <script src="./js/functions.js"></script>
	
  </body>
</html>
	<script>
var password = document.getElementById("inputPassword")
  , confirm_password = document.getElementById("confirmPassword");

  confirm_password.setCustomValidity("Passwords don't match.");
  
function validatePassword(){
  if(password.value != confirm_password.value) {
    confirm_password.setCustomValidity("Passwords don't match.");
    confirm_password.reportValidity();
  } else {
    confirm_password.setCustomValidity('');
  }
}
    
$('document').ready(function() {
    $('#submit').on ('click', function () {
        if ($('#confirmPassword').val() == $('#inputPassword').val()) {
          return true; 
        }
        else {
          validatePassword();
          return false;
        }
    });
    
    $('#confirmPassword').on ('keyup', function () {
        validatePassword();
    });
        
});
</script>
<?php
}
?>