<?PHP include 'functions.php'; ?>
<?php
	include 'requirecustomer.php';
	
	$sql=" SELECT t.toolID, t.abbrDescription, t.dailyRentalPrice, t.Category, t.DepositAmount FROM Handymantools.tool t";
	$sql= $sql . " WHERE t.category = '". $_GET["category"] ."' and t.toolID not in (";
	$sql= $sql . " SELECT toolid FROM Handymantools.unavailableToolsByDate";
	$sql= $sql . " WHERE startdate <= '". $_GET["endDate"] ."' and enddate >= '". $_GET["startDate"] ."'";
	$sql= $sql . " )";
	//echo $sql;
	$tools="<table class='table table-striped table-bordered'>
	<caption><b>Category:&nbsp;</b>". $_GET["category"] ."<br><b>Start:&nbsp;</b>". $_GET["startDate"] ."<br><b>End:&nbsp;</b>". $_GET["endDate"] ."</caption>
	<thead><tr><th>Tool ID</th><th>Abbreviated<br>Description</th><th>Deposit</th><th>Price/Day</th></tr></thead>";
	include('db_connect.php');	
	$result = mysqli_query($conn, $sql);
	while($row = $result->fetch_assoc()) {
			$tools= $tools . "<tr><td>".$row["toolID"]."</td>";
            $tools= $tools . "<td>".$row["abbrDescription"]."</td>";
            $tools= $tools . "<td>".asDollars($row["DepositAmount"])."</td>";
            $tools= $tools . "<td>".asDollars($row["dailyRentalPrice"])."</td></tr>";
	}
	$tools= $tools . "</table>";
	// Free result set
	mysqli_free_result($result);

	echo $tools;
?>