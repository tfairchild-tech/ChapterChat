<?PHP include 'requireclerk.php'; ?>
<?PHP include 'functions.php'; ?>
<!DOCTYPE html>
<html lang="en">
  <head>
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <!-- The above 3 meta tags *must* come first in the head; any other head content must come *after* these tags -->
    <meta name="description" content="">
    <meta name="author" content="">

    <title>Handyman Tools</title>

    <script src="https://ajax.googleapis.com/ajax/libs/jquery/1.12.0/jquery.min.js"></script>
    <script src="./bootstrap/js/bootstrap.min.js"></script>
    <!-- Bootstrap core CSS -->
    <link href="bootstrap/css/bootstrap.min.css" rel="stylesheet">

    <!-- Custom styles for this template -->
    <link href="bootstrap/css/jumbotron-narrow.css" rel="stylesheet">
    
    <!-- HTML5 shim and Respond.js for IE8 support of HTML5 elements and media queries -->
    <!--[if lt IE 9]>
      <script src="https://oss.maxcdn.com/html5shiv/3.7.2/html5shiv.min.js"></script>
      <script src="https://oss.maxcdn.com/respond/1.4.2/respond.min.js"></script>
    <![endif]-->
  </head>

  <body>

    <div class="container">
      <div class="header clearfix">
        <nav>
          <ul class="nav nav-pills pull-right">
            <li role="presentation" class="active"><a href="<?=$_SESSION['homepage']?>">Home</a></li>
            <li role="presentation"><a href="#" data-toggle="modal" data-target="#myModal">About</a></li>
            <li role="presentation"><a href="logout.php">Logout</a></li>
          </ul>
        </nav>
        <h3 class="text-muted">Handyman Tools</h3>
      </div>

      <div>
        <h1>All Reservations Report</h1>
        <table class="table table-bordered">
            <tr>
                <th>Reservation ID</th>
                <th>Customer</th>
                <th>Start Date</th>
                <th>End Date</th>
                <th>CC</th>
                <th>CC Expiration</th>
                <th>Pick Up Clerk</th>
                <th>Pick Up Date</th>
                <th>Drop Off Clerk</th>
                <th>Drop Off Date</th>
            </tr>
        <?PHP
            include('db_connect.php');
            $result = mysqli_query($conn, "CALL handymantools.getAllReservations()") or die("Query fail: " . mysqli_error($conn));
			while($row = $result->fetch_assoc()) {
				echo "<tr>";
                echo "<td>" . $row["ReservationID"] . "</td>";
                echo "<td>" . $row["CustomerLogin"] . "</td>";
                echo "<td>" . $row["StartDate"] . "</td>";
                echo "<td>" . $row["EndDate"] . "</td>";
                echo "<td>" . $row["CC"] . "</td>";
                echo "<td>" . $row["CCExpiration"] . "</td>";
                echo "<td>" . $row["PickUpClerkLogin"] . "</td>";
                echo "<td>" . $row["PickUpDate"] . "</td>";
                echo "<td>" . $row["DropOffClerkLogin"] . "</td>";
                echo "<td>" . $row["DropOffDate"] . "</td>";
                echo "</tr>";
            }
			 
			
        ?>
        </table>
      </div>

      <footer class="footer">
        <p>&copy; Team 37, Inc.</p>
      </footer>

      <?PHP include 'about.php'; ?>
    </div> <!-- /container -->

    <script src="./js/functions.js"></script>
  </body>
</html>
