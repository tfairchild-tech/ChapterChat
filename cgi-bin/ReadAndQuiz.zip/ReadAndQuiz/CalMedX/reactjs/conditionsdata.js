var CONDITIONSDATA = {
  'conditions': [
//	{
//	 displayName: 'Diabetes'
//	},
//	{
//	 displayName: 'HyperTension'
//	}
   ]	
};
