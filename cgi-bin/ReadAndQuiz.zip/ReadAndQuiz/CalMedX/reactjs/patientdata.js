var PATIENTSDATA = {
	'patients': [
		{
			displayName: 'Lacy Mcpherson',
			age: '43',
			gender: 'Female',
			pid: '13123',
			appointmentType: 'OPAC',
			appointmentReason: 'Chief Complaint',
			status: 'O',
			time: '8:00 AM'

		},
		{
			displayName: 'Alexa Craft',
			age: '41',
			gender: 'Female',
			pid: '13163',
			appointmentType: 'OPAC',
			appointmentReason: 'Ongoing Care',
			status: 'O',
			time: '8:30 AM'
		},
		{
			displayName: 'Ignacia Boyle',
			age: '62',
			gender: 'Female',
			pid: '13159',
			appointmentType: 'OPAC',
			appointmentReason: 'Chief Complaint',
			status: 'O',
			time: '9:00 AM'

		},
    /* 
		{
			displayName: 'Carter Adkins',
			age: '42',
			gender: 'Male',
			pid: '666383984-01',
			appointmentType: 'OPAC',
			appointmentReason: 'Wellness',
			status: 'O'
		},
		{
			displayName: 'Emery	Bolton',
			age: '55',
			gender: 'Male',
			pid: '666643100-01',
			appointmentType: 'OPAC',
			appointmentReason: 'Ongoing Care',
			status: 'O'
		}
    */
	]
};
