var PROCEDURESDATA = {
  'procedures': [
	{
	 displayName: 'Tubal Ligation',
	 dateString: 'May 1, 2010',
	 result: 'Successful ligation'
	},
	{
	 displayName: 'Appendectomy',
	 dateString: 'Jul 13, 1978',
	 result: 'Extraction completed'
	},	
   ]
}
