var COMPLAINTSDATA = {
   'complaints': [
	{
	 reason : 'Patient fainted this morning while getting ready for work.  Woke up on the floor, partially dressed.  Patient has been experiencing headaches and dizziness for the past few days.'
	}
   ]
};
