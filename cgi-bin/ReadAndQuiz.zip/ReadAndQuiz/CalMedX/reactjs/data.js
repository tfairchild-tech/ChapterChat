var DATA = {
   'vitals': [
     {
      bloodPressure: '120/70',
      bodyTemperature: '99.17',
      bodyWeight: '178 lbs',
      heartRate: '84'	
     },
   ],
};

PATIENTDATA = {
    name: 'Marla Dixon',
    age: 58,
    ethnicity: 'American',
    sex: 'F',
    dob: '12/12/1956',
    mrn: '402500433'
};
