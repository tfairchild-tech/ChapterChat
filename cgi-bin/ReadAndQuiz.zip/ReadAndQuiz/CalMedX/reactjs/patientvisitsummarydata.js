var PATIENTVISITSUMMARYDATA = {
   'patientVisitSummaries': [
	 {
	  reason: 'Chest pain',
	  dateString: 'May 20, 2015',
	  notes: 'Mild chest pain.'
	 },	
   ]
};
