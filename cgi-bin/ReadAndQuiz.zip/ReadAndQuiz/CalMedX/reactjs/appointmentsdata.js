var PATIENTSDATA = {
	'patients': [
		{
			displayName: 'Marla Dixon',
			age: '57',
			gender: 'Female',
			pid: '12345'
		},
		{
			displayName: 'Mark Dixon',
			age: '58',
			gender: 'Male',
			pid: '12346' 
		}
	]
}
