var IMMUNIZATIONSDATA = {
  'immunizations': [
	{
	 displayName: 'FLURIX',
	 date: 'Oct 07, 2005',
	 cvx: '140'
	},
	{
	 displayName: 'Tetanus and diphtheria toxoids adsorbed',
	 date: 'Jun 17, 2009',
	 cvx: '9'
	}
   ]	
}
