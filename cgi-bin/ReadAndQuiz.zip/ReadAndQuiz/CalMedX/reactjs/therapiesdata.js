var THERAPIESDATA = {
  'therapies': [
	{
	 displayName: 'Bullectomy',
	 result: 'successful removal of bulla',
	 targetArea: 'Right Lung',
	 date: '2012-07-12'
	}
   ]	
};
