var FAMILYHISTORYDATA = {
  'familyHistories': [
	{
	 displayName: 'Diabetes',
	 relationship: 'father, mother',
	 onsetAge: '41 years'
	},
	{
	 displayName: "Myocardial Infarction",
	 relationship: 'father',
	 onsetAge: 'none'
	}
   ]	

};
